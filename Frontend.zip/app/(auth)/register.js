import React, { useState } from "react";
import { View, Text, ScrollView } from "react-native";
import { useRouter, Link } from "expo-router";
import { Card } from "../../src/components/ui/Card";
import { Input } from "../../src/components/ui/Input";
import { Button } from "../../src/components/ui/Button";
import api from "../../src/lib/api";
import { colors, spacing, typography } from "../../src/theme";

export default function Register() {
  const router = useRouter();
  const [form, setForm] = useState({ name: "", email: "", password: "", studentPhone: "" });
  const [accessCode, setAccessCode] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  function set(key, value) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function handleRegister() {
    setError("");
    if (!form.name || !form.email || !form.password) {
      setError("Name, email, and password are required.");
      return;
    }
    setLoading(true);
    try {
      const res = await api.post("/auth/register-student", form);
      setAccessCode(res.data.user.accessCode);
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't register. Try again.");
    } finally {
      setLoading(false);
    }
  }

  if (accessCode) {
    return (
      <ScrollView contentContainerStyle={{ flexGrow: 1, backgroundColor: colors.background, padding: spacing.md, justifyContent: "center" }}>
        <View style={{ maxWidth: 420, alignSelf: "center", width: "100%" }}>
          <Card style={{ alignItems: "center" }}>
            <Text style={[typography.h2, { color: colors.primary, marginBottom: spacing.sm, textAlign: "center" }]}>
              You're registered!
            </Text>
            <Text style={[typography.body, { textAlign: "center", marginBottom: spacing.md }]}>
              Give this access code to a parent so they can view your progress:
            </Text>
            <View style={{ backgroundColor: colors.background, borderRadius: 8, padding: spacing.md, marginBottom: spacing.md }}>
              <Text style={[typography.h1, { color: colors.warning, letterSpacing: 2 }]}>{accessCode}</Text>
            </View>
            <Text style={[typography.caption, { color: colors.textMuted, textAlign: "center", marginBottom: spacing.md }]}>
              A teacher or assistant will add you to your group soon — you'll get full access once that happens.
            </Text>
            <Button title="Go to sign in" onPress={() => router.replace("/(auth)/login")} />
          </Card>
        </View>
      </ScrollView>
    );
  }

  return (
    <ScrollView contentContainerStyle={{ flexGrow: 1, backgroundColor: colors.background, padding: spacing.md, justifyContent: "center" }}>
      <View style={{ maxWidth: 420, alignSelf: "center", width: "100%" }}>
        <Text style={[typography.h1, { color: colors.primary, marginBottom: spacing.lg, textAlign: "center" }]}>
          Student registration
        </Text>
        <Card>
          <Input label="Full name" value={form.name} onChangeText={(v) => set("name", v)} />
          <Input label="Email" value={form.email} onChangeText={(v) => set("email", v)} autoCapitalize="none" keyboardType="email-address" />
          <Input label="Phone (optional)" value={form.studentPhone} onChangeText={(v) => set("studentPhone", v)} keyboardType="phone-pad" />
          <Input label="Password" value={form.password} onChangeText={(v) => set("password", v)} secureTextEntry />
          {error ? <Text style={{ color: colors.danger, marginBottom: spacing.sm }}>{error}</Text> : null}
          <Button title="Register" onPress={handleRegister} loading={loading} />
          <Link href="/(auth)/login" style={{ marginTop: spacing.md, textAlign: "center", color: colors.primary }}>
            Already have an account? Sign in
          </Link>
        </Card>
      </View>
    </ScrollView>
  );
}

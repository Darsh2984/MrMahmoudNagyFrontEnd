import React, { useEffect, useState, useCallback } from "react";
import { View, Text, Pressable, TextInput, ActivityIndicator } from "react-native";
import * as DocumentPicker from "expo-document-picker";
import { Screen } from "../../src/components/layout/Screen";
import { Card } from "../../src/components/ui/Card";
import { Button } from "../../src/components/ui/Button";
import api from "../../src/lib/api";
import { colors, spacing, radius, typography } from "../../src/theme";

export default function Content() {
  const [years, setYears] = useState([]);
  const [yearId, setYearId] = useState(null);
  const [level, setLevel] = useState("units");
  const [crumbs, setCrumbs] = useState([]); // {label, id, kind}
  const [items, setItems] = useState([]);
  const [newName, setNewName] = useState("");
  const [materialTitle, setMaterialTitle] = useState("");
  const [videoTitle, setVideoTitle] = useState("");
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    (async () => {
      try {
        const res = await api.get("/years/mine");
        setYears(res.data);
        if (res.data.length > 0) setYearId(res.data[0].id);
      } catch (err) {
        setError(err.response?.data?.msg || "Couldn't load years.");
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const loadUnits = useCallback(async (yId) => {
    if (!yId) return;
    setLoading(true);
    try {
      const res = await api.get(`/units/year/${yId}`);
      setItems(res.data);
      setLevel("units");
      setCrumbs([]);
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't load units.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadUnits(yearId); }, [yearId, loadUnits]);

  async function openUnit(unit) {
    const res = await api.get(`/units/${unit.id}`);
    setItems(res.data.chapters);
    setLevel("chapters");
    setCrumbs([{ label: unit.name, id: unit.id, kind: "unit" }]);
  }

  async function openChapter(chapter) {
    const res = await api.get(`/chapters/${chapter.id}`);
    setItems(res.data.topics);
    setLevel("topics");
    setCrumbs((c) => [...c, { label: chapter.name, id: chapter.id, kind: "chapter" }]);
  }

  async function openTopic(topic) {
    const res = await api.get(`/topics/${topic.id}`);
    setItems([
      ...res.data.materials.map((m) => ({ ...m, kind: "material" })),
      ...res.data.videos.map((v) => ({ ...v, kind: "video" })),
    ]);
    setLevel("resources");
    setCrumbs((c) => [...c, { label: topic.name, id: topic.id, kind: "topic" }]);
  }

  function currentParentId() {
    return crumbs.length ? crumbs[crumbs.length - 1].id : null;
  }

  async function handleCreate() {
    if (!newName.trim()) return;
    try {
      if (level === "units") {
        await api.post("/units", { name: newName.trim(), yearId });
        loadUnits(yearId);
      } else if (level === "chapters") {
        await api.post("/chapters", { name: newName.trim(), unitId: currentParentId() });
        openUnit({ id: currentParentId(), name: crumbs[0].label });
      } else if (level === "topics") {
        await api.post("/topics", { name: newName.trim(), chapterId: currentParentId() });
        openChapter({ id: currentParentId(), name: crumbs[1].label });
      }
      setNewName("");
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't create.");
    }
  }

  async function uploadFile(kind) {
    const title = kind === "material" ? materialTitle : videoTitle;
    if (!title.trim()) { setError(`Enter a title for the ${kind} first.`); return; }
    const pickerType = kind === "material" ? ["application/pdf", "image/*"] : ["video/*"];
    const result = await DocumentPicker.getDocumentAsync({ type: pickerType });
    if (result.canceled) return;

    const file = result.assets[0];
    const formData = new FormData();
    formData.append("title", title.trim());
    formData.append("topicId", currentParentId());
    formData.append("file", { uri: file.uri, name: file.name, type: file.mimeType || "application/octet-stream" });

    setUploading(true);
    setError("");
    try {
      await api.post(`/resources/${kind}`, formData, { headers: { "Content-Type": "multipart/form-data" } });
      if (kind === "material") setMaterialTitle(""); else setVideoTitle("");
      const topicId = currentParentId();
      openTopic({ id: topicId, name: crumbs[crumbs.length - 1].label });
    } catch (err) {
      setError(err.response?.data?.msg || `Couldn't upload ${kind}. (Note: needs a GCS bucket configured.)`);
    } finally {
      setUploading(false);
    }
  }

  if (loading) {
    return (
      <Screen scroll={false} style={{ alignItems: "center", justifyContent: "center" }}>
        <ActivityIndicator color={colors.primary} size="large" />
      </Screen>
    );
  }

  return (
    <Screen>
      {error ? <Card style={{ marginBottom: spacing.md }}><Text style={{ color: colors.danger }}>{error}</Text></Card> : null}

      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: spacing.xs, marginBottom: spacing.md }}>
        {years.map((y) => {
          const active = y.id === yearId;
          return (
            <Pressable key={y.id} onPress={() => setYearId(y.id)}
              style={{ backgroundColor: active ? colors.primary : colors.white, borderWidth: active ? 0 : 1, borderColor: colors.border, paddingVertical: spacing.sm, paddingHorizontal: spacing.md, borderRadius: radius.md }}>
              <Text style={{ color: active ? colors.white : colors.textPrimary, fontWeight: "600", fontSize: 13 }}>{y.name}</Text>
            </Pressable>
          );
        })}
      </View>

      <View style={{ flexDirection: "row", flexWrap: "wrap", marginBottom: spacing.sm }}>
        <Pressable onPress={() => loadUnits(yearId)}><Text style={[typography.caption, { color: colors.primary }]}>Units</Text></Pressable>
        {crumbs.map((c, i) => <Text key={i} style={typography.caption}>{"  ›  "}<Text style={{ color: colors.primary }}>{c.label}</Text></Text>)}
      </View>

      <Text style={[typography.h2, { color: colors.primary, marginBottom: spacing.md }]}>
        {crumbs.length ? crumbs[crumbs.length - 1].label : "Units"}
      </Text>

      {level !== "resources" ? (
        <View style={{ flexDirection: "row", marginBottom: spacing.md }}>
          <TextInput value={newName} onChangeText={setNewName}
            placeholder={`New ${level.slice(0, -1)} name`} placeholderTextColor={colors.textMuted}
            style={{ flex: 1, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.sm, marginRight: spacing.sm, backgroundColor: colors.white }} />
          <Button title="+ Add" variant="warning" onPress={handleCreate} />
        </View>
      ) : (
        <Card style={{ marginBottom: spacing.md }}>
          <Text style={[typography.bodyBold, { marginBottom: spacing.sm }]}>Upload to this topic</Text>
          <View style={{ flexDirection: "row", marginBottom: spacing.sm }}>
            <TextInput value={materialTitle} onChangeText={setMaterialTitle} placeholder="Material title"
              placeholderTextColor={colors.textMuted}
              style={{ flex: 1, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.sm, marginRight: spacing.sm, backgroundColor: colors.white }} />
            <Button title="Upload PDF/image" variant="secondary" onPress={() => uploadFile("material")} loading={uploading} />
          </View>
          <View style={{ flexDirection: "row" }}>
            <TextInput value={videoTitle} onChangeText={setVideoTitle} placeholder="Video title"
              placeholderTextColor={colors.textMuted}
              style={{ flex: 1, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.sm, marginRight: spacing.sm, backgroundColor: colors.white }} />
            <Button title="Upload video" variant="secondary" onPress={() => uploadFile("video")} loading={uploading} />
          </View>
        </Card>
      )}

      {items.length === 0 ? (
        <Card><Text style={typography.body}>Nothing here yet.</Text></Card>
      ) : (
        items.map((item) => (
          <Pressable key={item.id} onPress={() => {
            if (level === "units") openUnit(item);
            else if (level === "chapters") openChapter(item);
            else if (level === "topics") openTopic(item);
          }}>
            <Card style={{ marginBottom: spacing.sm, flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
              <Text style={typography.bodyBold}>
                {level === "resources" ? (item.kind === "video" ? "▶ " : "📄 ") : ""}
                {item.name || item.title}
              </Text>
              {level !== "resources" ? <Text style={{ color: colors.primary, fontWeight: "600" }}>→</Text> : null}
            </Card>
          </Pressable>
        ))
      )}
    </Screen>
  );
}

import React, { useEffect, useState, useCallback } from "react";
import { View, Text, Pressable, ScrollView, ActivityIndicator, Linking } from "react-native";
import { Screen } from "../../src/components/layout/Screen";
import { Card } from "../../src/components/ui/Card";
import api from "../../src/lib/api";
import { colors, spacing, typography } from "../../src/theme";

// One screen, drill-down state machine: units -> chapters -> topics -> resources.
export default function Resources() {
  const [yearId, setYearId] = useState(null);
  const [level, setLevel] = useState("units"); // units | chapters | topics | resources
  const [crumbs, setCrumbs] = useState([]); // [{label, level, id}]
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    (async () => {
      try {
        const me = await api.get("/auth/me");
        // groupMemberships only carries ids from /me — fetch full profile for the year.
        const profile = await api.get(`/students/${me.data.id}`);
        const firstGroup = profile.data.groupMemberships?.[0]?.group;
        if (!firstGroup) { setError("Not in a group yet."); setLoading(false); return; }
        setYearId(firstGroup.year.id);
      } catch (err) {
        setError(err.response?.data?.msg || "Couldn't load your year.");
        setLoading(false);
      }
    })();
  }, []);

  const loadUnits = useCallback(async (yId) => {
    setLoading(true);
    try {
      const res = await api.get(`/units/year/${yId}`);
      setItems(res.data);
      setLevel("units");
      setCrumbs([]);
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't load units.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { if (yearId) loadUnits(yearId); }, [yearId, loadUnits]);

  async function openUnit(unit) {
    setLoading(true);
    try {
      const res = await api.get(`/units/${unit.id}`);
      setItems(res.data.chapters);
      setLevel("chapters");
      setCrumbs([{ label: unit.name, level: "units" }]);
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't load chapters.");
    } finally {
      setLoading(false);
    }
  }

  async function openChapter(chapter) {
    setLoading(true);
    try {
      const res = await api.get(`/chapters/${chapter.id}`);
      setItems(res.data.topics);
      setLevel("topics");
      setCrumbs((c) => [...c, { label: chapter.name, level: "chapters" }]);
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't load topics.");
    } finally {
      setLoading(false);
    }
  }

  async function openTopic(topic) {
    setLoading(true);
    try {
      const res = await api.get(`/topics/${topic.id}`);
      const resources = [
        ...res.data.materials.map((m) => ({ ...m, kind: "material" })),
        ...res.data.videos.map((v) => ({ ...v, kind: "video" })),
      ];
      setItems(resources);
      setLevel("resources");
      setCrumbs((c) => [...c, { label: topic.name, level: "topics" }]);
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't load resources.");
    } finally {
      setLoading(false);
    }
  }

  function goToCrumb(index) {
    // Re-navigating from scratch is simplest and safest here rather than caching
    // every intermediate list — this browser is read-heavy, not deep, so it's cheap.
    if (index === -1) { loadUnits(yearId); return; }
    // Only "units" crumb is trivially restorable without re-fetching the parent id;
    // for chapters/topics crumbs we'd need the parent id, so simplest correct
    // behavior for now is: tapping any crumb before the last goes back to units.
    loadUnits(yearId);
  }

  function openResource(item) {
    const url = item.kind === "video" ? item.videoUrl : item.fileUrl;
    Linking.openURL(url);
  }

  if (loading) {
    return (
      <Screen scroll={false} style={{ alignItems: "center", justifyContent: "center" }}>
        <ActivityIndicator color={colors.primary} size="large" />
      </Screen>
    );
  }

  return (
    <Screen>
      {error ? <Card style={{ marginBottom: spacing.md }}><Text style={{ color: colors.danger }}>{error}</Text></Card> : null}

      <View style={{ flexDirection: "row", flexWrap: "wrap", marginBottom: spacing.sm }}>
        <Pressable onPress={() => goToCrumb(-1)}>
          <Text style={[typography.caption, { color: colors.primary }]}>Units</Text>
        </Pressable>
        {crumbs.map((c, i) => (
          <Text key={i} style={typography.caption}>
            {"  ›  "}
            <Text style={{ color: colors.primary }}>{c.label}</Text>
          </Text>
        ))}
      </View>

      <Text style={[typography.h2, { color: colors.primary, marginBottom: spacing.md }]}>
        {crumbs.length > 0 ? crumbs[crumbs.length - 1].label : "Units"}
      </Text>

      {items.length === 0 ? (
        <Card><Text style={typography.body}>Nothing here yet.</Text></Card>
      ) : (
        items.map((item) => (
          <Pressable
            key={item.id}
            onPress={() => {
              if (level === "units") openUnit(item);
              else if (level === "chapters") openChapter(item);
              else if (level === "topics") openTopic(item);
              else openResource(item);
            }}
          >
            <Card style={{ marginBottom: spacing.sm, flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
              <Text style={typography.bodyBold}>
                {level === "resources" ? (item.kind === "video" ? "▶ " : "📄 ") : ""}
                {item.name || item.title}
              </Text>
              <Text style={{ color: colors.primary, fontWeight: "600" }}>
                {level === "resources" ? (item.kind === "video" ? "Watch" : "Open") : "→"}
              </Text>
            </Card>
          </Pressable>
        ))
      )}
    </Screen>
  );
}

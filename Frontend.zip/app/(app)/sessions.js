import React, { useEffect, useState, useCallback } from "react";
import { View, Text, Pressable, TextInput, ActivityIndicator, Linking } from "react-native";
import * as DocumentPicker from "expo-document-picker";
import { Screen } from "../../src/components/layout/Screen";
import { Card } from "../../src/components/ui/Card";
import { Button } from "../../src/components/ui/Button";
import { Badge } from "../../src/components/ui/Badge";
import { useAuth } from "../../src/contexts/AuthContext";
import api from "../../src/lib/api";
import { formatDate } from "../../src/utils/formatDate";
import { colors, spacing, radius, typography } from "../../src/theme";

function TeacherSessionManager() {
  const [years, setYears] = useState([]);
  const [yearId, setYearId] = useState(null);
  const [groups, setGroups] = useState([]);
  const [groupId, setGroupId] = useState(null);
  const [sessions, setSessions] = useState([]);
  const [selectedSession, setSelectedSession] = useState(null);
  const [attendance, setAttendance] = useState({}); // studentId -> "PRESENT" | "ABSENT"
  const [newTitle, setNewTitle] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    (async () => {
      try {
        const res = await api.get("/years/mine");
        setYears(res.data);
        if (res.data.length) setYearId(res.data[0].id);
      } catch (err) {
        setError(err.response?.data?.msg || "Couldn't load years.");
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  useEffect(() => {
    if (!yearId) return;
    setGroupId(null); // reset first — otherwise a year with zero groups keeps the previous year's groupId
    api.get(`/groups/year/${yearId}`).then((res) => {
      setGroups(res.data);
      setGroupId(res.data.length ? res.data[0].id : null);
    }).catch(() => {});
  }, [yearId]);

  const loadSessions = useCallback(async (gId) => {
    if (!gId) return;
    try {
      const res = await api.get(`/sessions/group/${gId}`);
      setSessions(res.data);
      setSelectedSession(null);
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't load sessions.");
    }
  }, []);

  useEffect(() => { loadSessions(groupId); }, [groupId, loadSessions]);

  async function openSession(session) {
    try {
      const res = await api.get(`/sessions/${session.id}`);
      setSelectedSession(res.data);
      const records = {};
      res.data.attendance.forEach((a) => { records[a.studentId] = a.status; });
      setAttendance(records);
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't load session.");
    }
  }

  async function handleCreateSession() {
    if (!newTitle.trim() || !groupId) return;
    try {
      await api.post("/sessions", { title: newTitle.trim(), yearId, groupId });
      setNewTitle("");
      loadSessions(groupId);
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't create session.");
    }
  }

  function toggleAttendance(studentId) {
    setAttendance((a) => ({ ...a, [studentId]: a[studentId] === "PRESENT" ? "ABSENT" : "PRESENT" }));
  }

  async function saveAttendance() {
    const records = Object.entries(attendance).map(([studentId, status]) => ({ studentId, status }));
    try {
      await api.post(`/sessions/${selectedSession.id}/attendance`, { records });
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't save attendance.");
    }
  }

  if (loading) {
    return (
      <Screen scroll={false} style={{ alignItems: "center", justifyContent: "center" }}>
        <ActivityIndicator color={colors.primary} size="large" />
      </Screen>
    );
  }

  const currentGroup = groups.find((g) => g.id === groupId);

  return (
    <Screen>
      {error ? <Card style={{ marginBottom: spacing.md }}><Text style={{ color: colors.danger }}>{error}</Text></Card> : null}

      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: spacing.xs, marginBottom: spacing.sm }}>
        {years.map((y) => (
          <Pressable key={y.id} onPress={() => setYearId(y.id)}
            style={{ backgroundColor: y.id === yearId ? colors.primary : colors.white, borderWidth: y.id === yearId ? 0 : 1, borderColor: colors.border, padding: spacing.sm, borderRadius: radius.md }}>
            <Text style={{ color: y.id === yearId ? colors.white : colors.textPrimary, fontSize: 13, fontWeight: "600" }}>{y.name}</Text>
          </Pressable>
        ))}
      </View>

      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: spacing.xs, marginBottom: spacing.md }}>
        {groups.map((g) => (
          <Pressable key={g.id} onPress={() => setGroupId(g.id)}
            style={{ backgroundColor: g.id === groupId ? colors.secondary : colors.white, borderWidth: g.id === groupId ? 0 : 1, borderColor: colors.border, padding: spacing.sm, borderRadius: radius.md }}>
            <Text style={{ color: g.id === groupId ? colors.white : colors.textPrimary, fontSize: 12, fontWeight: "600" }}>{g.name}</Text>
          </Pressable>
        ))}
      </View>

      <Text style={[typography.h1, { color: colors.primary, marginBottom: spacing.md }]}>
        Sessions {currentGroup ? `— ${currentGroup.name}` : ""}
      </Text>

      {groups.length === 0 ? (
        <Card style={{ marginBottom: spacing.md }}>
          <Text style={typography.body}>This year has no groups yet — create one in Groups first before adding sessions.</Text>
        </Card>
      ) : null}

      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: spacing.md }}>
        <View style={{ flex: 1, minWidth: 220 }}>
          {groups.length > 0 ? (
            <View style={{ flexDirection: "row", marginBottom: spacing.sm }}>
              <TextInput value={newTitle} onChangeText={setNewTitle} placeholder="New session title" placeholderTextColor={colors.textMuted}
                style={{ flex: 1, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.sm, marginRight: spacing.sm, backgroundColor: colors.white }} />
              <Button title="Add" variant="warning" onPress={handleCreateSession} disabled={!groupId} />
            </View>
          ) : null}
          {sessions.map((s) => {
            const active = selectedSession?.id === s.id;
            return (
              <Pressable key={s.id} onPress={() => openSession(s)}>
                <Card style={{ backgroundColor: active ? colors.primary : colors.white, marginBottom: spacing.sm }}>
                  <Text style={{ color: active ? colors.white : colors.textPrimary, fontWeight: "700", fontSize: 14 }}>
                    Session — {formatDate(s.date)}
                  </Text>
                  <Text style={{ color: active ? "#C9D6D3" : colors.textMuted, fontSize: 12, marginTop: 2 }}>{s.title}</Text>
                </Card>
              </Pressable>
            );
          })}
        </View>

        <View style={{ flex: 1.3, minWidth: 280 }}>
          {!selectedSession ? (
            <Card><Text style={typography.body}>Select a session to mark attendance.</Text></Card>
          ) : (
            <Card>
              <Text style={typography.h3}>{selectedSession.title}</Text>
              <Text style={[typography.caption, { color: colors.textMuted, marginBottom: spacing.sm }]}>
                {formatDate(selectedSession.date)}
              </Text>
              {selectedSession.attendance.length === 0 ? (
                <Text style={typography.caption}>This group has no students yet — add some before marking attendance.</Text>
              ) : null}
              {selectedSession.attendance.map((a) => (
                <Pressable key={a.studentId} onPress={() => toggleAttendance(a.studentId)}
                  style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingVertical: spacing.xs, borderBottomWidth: 1, borderBottomColor: colors.background }}>
                  <Text style={typography.body}>{a.student.name}</Text>
                  <View style={{ backgroundColor: attendance[a.studentId] === "PRESENT" ? colors.secondary : "#EDE9E2", paddingVertical: 4, paddingHorizontal: spacing.sm, borderRadius: radius.pill }}>
                    <Text style={{ color: attendance[a.studentId] === "PRESENT" ? colors.white : colors.textMuted, fontSize: 11, fontWeight: "600" }}>
                      {attendance[a.studentId] === "PRESENT" ? "Present" : "Absent"}
                    </Text>
                  </View>
                </Pressable>
              ))}
              <Button title="Save attendance" variant="warning" onPress={saveAttendance} style={{ marginTop: spacing.md }} />

              <LiveQuestionsPanel session={selectedSession} onPosted={() => openSession(selectedSession)} />
            </Card>
          )}
        </View>
      </View>
    </Screen>
  );
}

function LiveQuestionsPanel({ session, onPosted }) {
  const [prompt, setPrompt] = useState("");
  const [gradeOutOf, setGradeOutOf] = useState("5");
  const [expandedId, setExpandedId] = useState(null);
  const [answers, setAnswers] = useState([]);
  const [gradeInputs, setGradeInputs] = useState({});
  const [error, setError] = useState("");

  async function postQuestion() {
    if (!prompt.trim()) return;
    try {
      await api.post("/live-questions", { sessionId: session.id, prompt: prompt.trim(), gradeOutOf: parseFloat(gradeOutOf) || 5 });
      setPrompt("");
      onPosted();
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't post question.");
    }
  }

  async function expand(liveQuestionId) {
    if (expandedId === liveQuestionId) { setExpandedId(null); return; }
    try {
      const res = await api.get(`/live-questions/${liveQuestionId}/answers`);
      setAnswers(res.data);
      setExpandedId(liveQuestionId);
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't load answers.");
    }
  }

  async function saveGrade(answerId) {
    const grade = parseFloat(gradeInputs[answerId]);
    if (isNaN(grade)) return;
    try {
      await api.patch(`/live-questions/answer/${answerId}/grade`, { grade });
      const res = await api.get(`/live-questions/${expandedId}/answers`);
      setAnswers(res.data);
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't save grade.");
    }
  }

  return (
    <View style={{ marginTop: spacing.lg }}>
      <Text style={[typography.h3, { marginBottom: spacing.sm }]}>Live Questions</Text>
      {error ? <Text style={{ color: colors.danger, marginBottom: spacing.sm }}>{error}</Text> : null}

      <View style={{ backgroundColor: colors.background, borderRadius: radius.md, padding: spacing.sm, marginBottom: spacing.sm }}>
        <TextInput value={prompt} onChangeText={setPrompt} placeholder="Question prompt / reference" placeholderTextColor={colors.textMuted}
          style={{ backgroundColor: colors.white, borderRadius: radius.sm, padding: spacing.sm, marginBottom: spacing.sm }} />
        <View style={{ flexDirection: "row", gap: spacing.sm }}>
          <TextInput value={gradeOutOf} onChangeText={setGradeOutOf} placeholder="Marks" keyboardType="numeric" placeholderTextColor={colors.textMuted}
            style={{ flex: 1, backgroundColor: colors.white, borderRadius: radius.sm, padding: spacing.sm }} />
          <Button title="Post" variant="warning" onPress={postQuestion} />
        </View>
      </View>

      {(session.liveQuestions || []).map((q) => (
        <View key={q.id} style={{ borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.sm, marginBottom: spacing.sm }}>
          <Pressable onPress={() => expand(q.id)} style={{ flexDirection: "row", justifyContent: "space-between" }}>
            <Text style={typography.bodyBold}>{q.prompt} — out of {q.gradeOutOf}</Text>
            <Text style={{ color: colors.primary }}>{expandedId === q.id ? "▲" : "▼"}</Text>
          </Pressable>
          {expandedId === q.id ? (
            <View style={{ marginTop: spacing.sm }}>
              {answers.map((a) => (
                <View key={a.id} style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingVertical: spacing.xs, borderTopWidth: 1, borderTopColor: colors.background }}>
                  <Pressable onPress={() => Linking.openURL(a.answerImageUrl)}>
                    <Text style={{ color: colors.primary, fontSize: 12 }}>📷 {a.student.name}</Text>
                  </Pressable>
                  {a.status === "GRADED" ? (
                    <Badge label={`Graded: ${a.grade}/${q.gradeOutOf}`} tone="success" />
                  ) : (
                    <View style={{ flexDirection: "row", gap: spacing.xs, alignItems: "center" }}>
                      <TextInput value={gradeInputs[a.id] || ""} onChangeText={(v) => setGradeInputs((g) => ({ ...g, [a.id]: v }))}
                        placeholder="grade" keyboardType="numeric" placeholderTextColor={colors.textMuted}
                        style={{ width: 50, borderWidth: 1, borderColor: colors.border, borderRadius: radius.sm, padding: 4, fontSize: 12 }} />
                      <Pressable onPress={() => saveGrade(a.id)} style={{ backgroundColor: colors.secondary, paddingVertical: 4, paddingHorizontal: spacing.sm, borderRadius: radius.sm }}>
                        <Text style={{ color: colors.white, fontSize: 11, fontWeight: "600" }}>Save</Text>
                      </Pressable>
                    </View>
                  )}
                </View>
              ))}
            </View>
          ) : null}
        </View>
      ))}
    </View>
  );
}

function StudentSessionView() {
  const [sessions, setSessions] = useState([]);
  const [selected, setSelected] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  useEffect(() => {
    (async () => {
      try {
        const profile = await api.get(`/students/${user.id}`);
        const group = profile.data.groupMemberships?.[0]?.group;
        if (!group) { setError("Not in a group yet."); setLoading(false); return; }
        const res = await api.get(`/sessions/group/${group.id}`);
        setSessions(res.data);
        if (res.data.length) openSession(res.data[0].id);
      } catch (err) {
        setError(err.response?.data?.msg || "Couldn't load sessions.");
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  async function openSession(sessionId) {
    try {
      const res = await api.get(`/sessions/${sessionId}`);
      setSelected(res.data);
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't load session.");
    }
  }

  async function answerQuestion(liveQuestionId) {
    const result = await DocumentPicker.getDocumentAsync({ type: ["image/*", "application/pdf"] });
    if (result.canceled) return;
    const file = result.assets[0];
    const formData = new FormData();
    formData.append("file", { uri: file.uri, name: file.name, type: file.mimeType || "image/jpeg" });
    try {
      await api.post(`/live-questions/${liveQuestionId}/answer`, formData, { headers: { "Content-Type": "multipart/form-data" } });
      openSession(selected.id);
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't upload answer.");
    }
  }

  if (loading) {
    return (
      <Screen scroll={false} style={{ alignItems: "center", justifyContent: "center" }}>
        <ActivityIndicator color={colors.primary} size="large" />
      </Screen>
    );
  }

  return (
    <Screen>
      {error ? <Card style={{ marginBottom: spacing.md }}><Text style={{ color: colors.danger }}>{error}</Text></Card> : null}
      <Text style={[typography.caption, { color: colors.textMuted }]}>Today's session</Text>
      <Text style={[typography.h1, { color: colors.primary, marginBottom: spacing.md }]}>{selected?.title || "No sessions yet"}</Text>

      {(selected?.liveQuestions || []).length === 0 ? (
        <Card><Text style={typography.body}>No live questions posted yet.</Text></Card>
      ) : (
        selected.liveQuestions.map((q) => {
          const myAnswer = q.answers.find((a) => a.studentId === user.id);
          return (
            <Card key={q.id} style={{ marginBottom: spacing.sm }}>
              <Text style={[typography.bodyBold, { marginBottom: spacing.xs }]}>{q.prompt} — {q.gradeOutOf} marks</Text>
              {myAnswer ? (
                myAnswer.status === "GRADED" ? (
                  <Badge label={`Graded: ${myAnswer.grade}/${q.gradeOutOf}`} tone="success" />
                ) : (
                  <Badge label="✓ Answered — awaiting grade" tone="warning" />
                )
              ) : (
                <Button title="📷 Upload photo of your answer" variant="warning" onPress={() => answerQuestion(q.id)} />
              )}
            </Card>
          );
        })
      )}
    </Screen>
  );
}

export default function Sessions() {
  const { user } = useAuth();
  if (user?.role === "STUDENT") return <StudentSessionView />;
  return <TeacherSessionManager />;
}

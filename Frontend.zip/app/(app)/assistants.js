import React, { useEffect, useState, useCallback } from "react";
import { View, Text, Pressable, TextInput, ActivityIndicator } from "react-native";
import { Screen } from "../../src/components/layout/Screen";
import { Card } from "../../src/components/ui/Card";
import { Button } from "../../src/components/ui/Button";
import { Badge } from "../../src/components/ui/Badge";
import { useAuth } from "../../src/contexts/AuthContext";
import api from "../../src/lib/api";
import { colors, spacing, radius, typography } from "../../src/theme";

const PERMISSIONS = [
  ["canGradeHomework", "Grade homework"],
  ["canGradeLiveQuestions", "Grade live questions"],
  ["canManageTickets", "Manage tickets"],
  ["canUploadResources", "Upload resources"],
  ["canManageQuizzes", "Manage quizzes"],
  ["canManageSessions", "Manage sessions"],
  ["canViewPerformance", "View performance"],
  ["canManageTasks", "Manage tasks"],
];

export default function Assistants() {
  const { user } = useAuth();
  const isTeacher = user?.role === "TEACHER";

  const [assistants, setAssistants] = useState([]);
  const [showNew, setShowNew] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [managedByHeadId, setManagedByHeadId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    try {
      const res = await api.get("/auth/assistants");
      setAssistants(res.data);
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't load assistants.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const heads = assistants.filter((a) => a.isHeadAssistant);

  async function handleCreate() {
    if (!form.name || !form.email || !form.password) {
      setError("Name, email, and password are required.");
      return;
    }
    try {
      await api.post("/auth/create-assistant", { ...form, managedByHeadId });
      setForm({ name: "", email: "", password: "" });
      setShowNew(false);
      load();
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't create assistant.");
    }
  }

  async function handlePromote(id) {
    try { await api.post(`/auth/promote-head/${id}`); load(); }
    catch (err) { setError(err.response?.data?.msg || "Couldn't promote."); }
  }

  async function handleDemote(id) {
    try { await api.post(`/auth/demote-head/${id}`, {}); load(); }
    catch (err) { setError(err.response?.data?.msg || "Couldn't demote."); }
  }

  async function handleDelete(id) {
    try { await api.delete(`/auth/assistants/${id}`); load(); }
    catch (err) { setError(err.response?.data?.msg || "Couldn't delete."); }
  }

  async function togglePermission(assistant, key) {
    const updated = { ...assistant.permissions, [key]: !assistant.permissions?.[key] };
    try {
      await api.patch(`/auth/assistants/${assistant.id}/permissions`, { permissions: updated });
      setAssistants((list) => list.map((a) => (a.id === assistant.id ? { ...a, permissions: updated } : a)));
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't update permission.");
    }
  }

  if (loading) {
    return (
      <Screen scroll={false} style={{ alignItems: "center", justifyContent: "center" }}>
        <ActivityIndicator color={colors.primary} size="large" />
      </Screen>
    );
  }

  return (
    <Screen>
      <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: spacing.md }}>
        <Text style={[typography.h1, { color: colors.primary }]}>Assistants</Text>
        {isTeacher ? <Button title="+ New assistant" variant="warning" onPress={() => setShowNew((s) => !s)} /> : null}
      </View>

      {error ? <Card style={{ marginBottom: spacing.md }}><Text style={{ color: colors.danger }}>{error}</Text></Card> : null}

      {showNew ? (
        <Card style={{ marginBottom: spacing.md }}>
          <TextInput value={form.name} onChangeText={(v) => setForm((f) => ({ ...f, name: v }))} placeholder="Name" placeholderTextColor={colors.textMuted}
            style={{ borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.sm, marginBottom: spacing.sm, backgroundColor: colors.white }} />
          <TextInput value={form.email} onChangeText={(v) => setForm((f) => ({ ...f, email: v }))} placeholder="Email" autoCapitalize="none" placeholderTextColor={colors.textMuted}
            style={{ borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.sm, marginBottom: spacing.sm, backgroundColor: colors.white }} />
          <TextInput value={form.password} onChangeText={(v) => setForm((f) => ({ ...f, password: v }))} placeholder="Password" secureTextEntry placeholderTextColor={colors.textMuted}
            style={{ borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.sm, marginBottom: spacing.sm, backgroundColor: colors.white }} />
          {heads.length > 0 ? (
            <>
              <Text style={[typography.caption, { marginBottom: spacing.xs }]}>Reports to which Head?</Text>
              <View style={{ flexDirection: "row", flexWrap: "wrap", gap: spacing.xs, marginBottom: spacing.sm }}>
                {heads.map((h) => (
                  <Pressable key={h.id} onPress={() => setManagedByHeadId(h.id)}
                    style={{ backgroundColor: managedByHeadId === h.id ? colors.primary : colors.white, borderWidth: 1, borderColor: colors.border, padding: spacing.sm, borderRadius: radius.md }}>
                    <Text style={{ color: managedByHeadId === h.id ? colors.white : colors.textPrimary, fontSize: 12 }}>{h.name}</Text>
                  </Pressable>
                ))}
              </View>
            </>
          ) : null}
          <Button title="Create" onPress={handleCreate} />
        </Card>
      ) : null}

      {assistants.length === 0 ? (
        <Card><Text style={typography.body}>No assistants yet.</Text></Card>
      ) : (
        assistants.map((a) => (
          <Card key={a.id} style={{ marginBottom: spacing.sm }}>
            <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", marginBottom: spacing.xs }}>
              <View style={{ flexDirection: "row", alignItems: "center", gap: spacing.xs }}>
                <Text style={typography.bodyBold}>{a.name}</Text>
                {a.isHeadAssistant ? <Badge label="HEAD" tone="info" /> : null}
              </View>
              {isTeacher ? (
                <View style={{ flexDirection: "row", gap: spacing.md }}>
                  {a.isHeadAssistant ? (
                    <Pressable onPress={() => handleDemote(a.id)}><Text style={{ color: colors.secondary, fontWeight: "600", fontSize: 12 }}>Demote</Text></Pressable>
                  ) : (
                    <Pressable onPress={() => handlePromote(a.id)}><Text style={{ color: colors.primary, fontWeight: "600", fontSize: 12 }}>Promote to Head</Text></Pressable>
                  )}
                  <Pressable onPress={() => handleDelete(a.id)}><Text style={{ color: colors.danger, fontWeight: "600", fontSize: 12 }}>Delete</Text></Pressable>
                </View>
              ) : null}
            </View>
            <Text style={[typography.caption, { color: colors.textMuted, marginBottom: spacing.sm }]}>{a.email}</Text>

            {a.isHeadAssistant ? (
              <Text style={[typography.caption, { fontStyle: "italic", color: colors.textMuted }]}>Heads have all permissions automatically</Text>
            ) : (
              <View style={{ flexDirection: "row", flexWrap: "wrap", gap: spacing.xs }}>
                {PERMISSIONS.map(([key, label]) => {
                  const on = !!a.permissions?.[key];
                  return (
                    <Pressable key={key} onPress={() => togglePermission(a, key)}
                      style={{ backgroundColor: on ? colors.secondary : "#EDE9E2", paddingVertical: 4, paddingHorizontal: spacing.sm, borderRadius: radius.pill }}>
                      <Text style={{ color: on ? colors.white : colors.textPrimary, fontSize: 11, fontWeight: "600" }}>{on ? "✓ " : ""}{label}</Text>
                    </Pressable>
                  );
                })}
              </View>
            )}
          </Card>
        ))
      )}
    </Screen>
  );
}

import React, { useEffect, useState, useCallback } from "react";
import { View, Text, Pressable, TextInput, ActivityIndicator } from "react-native";
import { Screen } from "../../src/components/layout/Screen";
import { Card } from "../../src/components/ui/Card";
import { Button } from "../../src/components/ui/Button";
import api from "../../src/lib/api";
import { formatDate } from "../../src/utils/formatDate";
import { colors, spacing, radius, typography } from "../../src/theme";

export default function InClassQuizzes() {
  const [years, setYears] = useState([]);
  const [yearId, setYearId] = useState(null);
  const [groups, setGroups] = useState([]);
  const [groupId, setGroupId] = useState(null);
  const [studentNames, setStudentNames] = useState({}); // studentId -> name
  const [quizzes, setQuizzes] = useState([]);
  const [selectedQuiz, setSelectedQuiz] = useState(null);
  const [gradeInputs, setGradeInputs] = useState({}); // studentId -> grade text
  const [quizName, setQuizName] = useState("");
  const [date, setDate] = useState("");
  const [gradeOutOf, setGradeOutOf] = useState("20");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    (async () => {
      try {
        const res = await api.get("/years/mine");
        setYears(res.data);
        if (res.data.length) setYearId(res.data[0].id);
      } catch (err) {
        setError(err.response?.data?.msg || "Couldn't load years.");
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  useEffect(() => {
    if (!yearId) return;
    setGroupId(null);
    api.get(`/groups/year/${yearId}`).then((res) => {
      setGroups(res.data);
      setGroupId(res.data.length ? res.data[0].id : null);
    }).catch(() => {});
  }, [yearId]);

  const loadQuizzes = useCallback(async (gId) => {
    if (!gId) { setQuizzes([]); return; }
    try {
      const [quizzesRes, groupRes] = await Promise.all([
        api.get(`/inclassquiz/${gId}`),
        api.get(`/groups/${gId}`),
      ]);
      setQuizzes(quizzesRes.data);
      const names = {};
      groupRes.data.members.forEach((m) => { names[m.student.id] = m.student.name; });
      setStudentNames(names);
      setSelectedQuiz(null);
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't load quizzes.");
    }
  }, []);

  useEffect(() => { loadQuizzes(groupId); }, [groupId, loadQuizzes]);

  async function handleCreate() {
    if (!quizName.trim() || !date.trim() || !groupId) return;
    try {
      await api.post("/inclassquiz", { yearId, groupId, quizName: quizName.trim(), date: date.trim(), gradeOutOf: parseFloat(gradeOutOf) || 20 });
      setQuizName(""); setDate(""); setGradeOutOf("20");
      loadQuizzes(groupId);
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't create quiz.");
    }
  }

  function selectQuiz(q) {
    setSelectedQuiz(q);
    const inputs = {};
    (q.studentGrades || []).forEach((sg) => { inputs[sg.studentId] = sg.grade != null ? String(sg.grade) : ""; });
    setGradeInputs(inputs);
  }

  const [editing, setEditing] = useState(false);

  async function handleUpdate() {
    try {
      await api.put(`/inclassquiz/${selectedQuiz.id}`, { quizName, date, gradeOutOf: parseFloat(gradeOutOf) || selectedQuiz.gradeOutOf });
      setEditing(false);
      loadQuizzes(groupId);
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't update quiz.");
    }
  }

  async function handleDelete(quizId) {
    try {
      await api.delete(`/inclassquiz/${quizId}`);
      setSelectedQuiz(null);
      loadQuizzes(groupId);
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't delete quiz.");
    }
  }

  async function saveGrades() {
    const studentGrades = Object.entries(gradeInputs).map(([studentId, val]) => ({
      studentId,
      grade: val.trim() === "" ? null : parseFloat(val),
      percentage: val.trim() === "" ? null : Math.round((parseFloat(val) / selectedQuiz.gradeOutOf) * 100),
      letterGrade: "",
    }));
    try {
      await api.put(`/inclassquiz/${selectedQuiz.id}/grades`, { studentGrades });
      loadQuizzes(groupId);
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't save grades.");
    }
  }

  if (loading) {
    return (
      <Screen scroll={false} style={{ alignItems: "center", justifyContent: "center" }}>
        <ActivityIndicator color={colors.primary} size="large" />
      </Screen>
    );
  }

  const currentGroup = groups.find((g) => g.id === groupId);

  return (
    <Screen>
      {error ? <Card style={{ marginBottom: spacing.md }}><Text style={{ color: colors.danger }}>{error}</Text></Card> : null}

      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: spacing.xs, marginBottom: spacing.sm }}>
        {years.map((y) => (
          <Pressable key={y.id} onPress={() => setYearId(y.id)}
            style={{ backgroundColor: y.id === yearId ? colors.primary : colors.white, borderWidth: y.id === yearId ? 0 : 1, borderColor: colors.border, padding: spacing.sm, borderRadius: radius.md }}>
            <Text style={{ color: y.id === yearId ? colors.white : colors.textPrimary, fontSize: 13, fontWeight: "600" }}>{y.name}</Text>
          </Pressable>
        ))}
      </View>
      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: spacing.xs, marginBottom: spacing.md }}>
        {groups.map((g) => (
          <Pressable key={g.id} onPress={() => setGroupId(g.id)}
            style={{ backgroundColor: g.id === groupId ? colors.secondary : colors.white, borderWidth: g.id === groupId ? 0 : 1, borderColor: colors.border, padding: spacing.sm, borderRadius: radius.md }}>
            <Text style={{ color: g.id === groupId ? colors.white : colors.textPrimary, fontSize: 12, fontWeight: "600" }}>{g.name}</Text>
          </Pressable>
        ))}
      </View>

      <Text style={[typography.h1, { color: colors.primary, marginBottom: spacing.md }]}>
        In-Class Quizzes {currentGroup ? `— ${currentGroup.name}` : ""}
      </Text>

      {groups.length === 0 ? (
        <Card><Text style={typography.body}>This year has no groups yet — create one in Groups first.</Text></Card>
      ) : (
        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: spacing.md }}>
          <View style={{ flex: 1, minWidth: 220 }}>
            <View style={{ backgroundColor: colors.white, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border, padding: spacing.sm, marginBottom: spacing.sm }}>
              <TextInput value={quizName} onChangeText={setQuizName} placeholder="Quiz name" placeholderTextColor={colors.textMuted}
                style={{ borderWidth: 1, borderColor: colors.border, borderRadius: radius.sm, padding: spacing.sm, marginBottom: spacing.sm }} />
              <View style={{ flexDirection: "row", gap: spacing.sm, marginBottom: spacing.sm }}>
                <TextInput value={date} onChangeText={setDate} placeholder="Date (YYYY-MM-DD)" placeholderTextColor={colors.textMuted}
                  style={{ flex: 1, borderWidth: 1, borderColor: colors.border, borderRadius: radius.sm, padding: spacing.sm }} />
                <TextInput value={gradeOutOf} onChangeText={setGradeOutOf} placeholder="Out of" keyboardType="numeric" placeholderTextColor={colors.textMuted}
                  style={{ width: 80, borderWidth: 1, borderColor: colors.border, borderRadius: radius.sm, padding: spacing.sm }} />
              </View>
              <Button title="+ New quiz" variant="warning" onPress={handleCreate} />
            </View>

            {quizzes.map((q) => {
              const active = selectedQuiz?.id === q.id;
              return (
                <Pressable key={q.id} onPress={() => selectQuiz(q)}>
                  <Card style={{ backgroundColor: active ? colors.primary : colors.white, marginBottom: spacing.sm }}>
                    <Text style={{ color: active ? colors.white : colors.textPrimary, fontWeight: "700", fontSize: 14 }}>{q.quizName}</Text>
                    <Text style={{ color: active ? "#C9D6D3" : colors.textMuted, fontSize: 12, marginTop: 2 }}>
                      {formatDate(q.date)} · out of {q.gradeOutOf}
                    </Text>
                  </Card>
                </Pressable>
              );
            })}
          </View>

          <View style={{ flex: 1.3, minWidth: 280 }}>
            {!selectedQuiz ? (
              <Card><Text style={typography.body}>Select a quiz to enter grades.</Text></Card>
            ) : (
              <Card>
                <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" }}>
                  <Text style={typography.h3}>{selectedQuiz.quizName}</Text>
                  <View style={{ flexDirection: "row", gap: spacing.sm }}>
                    <Pressable onPress={() => { setEditing((e) => !e); setQuizName(selectedQuiz.quizName); setDate(selectedQuiz.date.slice(0, 10)); setGradeOutOf(String(selectedQuiz.gradeOutOf)); }}>
                      <Text style={{ color: colors.primary, fontWeight: "600", fontSize: 12 }}>Edit</Text>
                    </Pressable>
                    <Pressable onPress={() => handleDelete(selectedQuiz.id)}>
                      <Text style={{ color: colors.danger, fontWeight: "600", fontSize: 12 }}>Delete</Text>
                    </Pressable>
                  </View>
                </View>
                {editing ? (
                  <View style={{ marginBottom: spacing.sm }}>
                    <TextInput value={quizName} onChangeText={setQuizName} placeholder="Quiz name" placeholderTextColor={colors.textMuted}
                      style={{ borderWidth: 1, borderColor: colors.border, borderRadius: radius.sm, padding: spacing.sm, marginBottom: spacing.sm, backgroundColor: colors.white }} />
                    <View style={{ flexDirection: "row", gap: spacing.sm, marginBottom: spacing.sm }}>
                      <TextInput value={date} onChangeText={setDate} placeholder="YYYY-MM-DD" placeholderTextColor={colors.textMuted}
                        style={{ flex: 1, borderWidth: 1, borderColor: colors.border, borderRadius: radius.sm, padding: spacing.sm, backgroundColor: colors.white }} />
                      <TextInput value={gradeOutOf} onChangeText={setGradeOutOf} placeholder="Out of" keyboardType="numeric" placeholderTextColor={colors.textMuted}
                        style={{ width: 80, borderWidth: 1, borderColor: colors.border, borderRadius: radius.sm, padding: spacing.sm, backgroundColor: colors.white }} />
                    </View>
                    <Button title="Save changes" variant="secondary" onPress={handleUpdate} />
                  </View>
                ) : (
                  <Text style={[typography.caption, { color: colors.textMuted, marginBottom: spacing.sm }]}>
                    {formatDate(selectedQuiz.date)} · out of {selectedQuiz.gradeOutOf} marks
                  </Text>
                )}
                {(selectedQuiz.studentGrades || []).map((sg) => (
                  <View key={sg.studentId} style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingVertical: spacing.xs, borderBottomWidth: 1, borderBottomColor: colors.background }}>
                    <Text style={typography.body}>{studentNames[sg.studentId] || sg.studentId}</Text>
                    <TextInput
                      value={gradeInputs[sg.studentId] ?? ""}
                      onChangeText={(v) => setGradeInputs((g) => ({ ...g, [sg.studentId]: v }))}
                      placeholder="—"
                      keyboardType="numeric"
                      placeholderTextColor={colors.textMuted}
                      style={{ width: 60, borderWidth: 1, borderColor: colors.border, borderRadius: radius.sm, padding: spacing.xs, textAlign: "center", backgroundColor: colors.white }}
                    />
                  </View>
                ))}
                <Button title="Save grades" variant="warning" onPress={saveGrades} style={{ marginTop: spacing.md }} />
              </Card>
            )}
          </View>
        </View>
      )}
    </Screen>
  );
}

import React, { useEffect, useState, useCallback } from "react";
import { View, Text, Pressable, ScrollView, ActivityIndicator, TextInput } from "react-native";
import { Screen } from "../../src/components/layout/Screen";
import { Card } from "../../src/components/ui/Card";
import { Button } from "../../src/components/ui/Button";
import api from "../../src/lib/api";
import { colors, spacing, radius, typography } from "../../src/theme";

export default function Groups() {
  const [years, setYears] = useState([]);
  const [selectedYearId, setSelectedYearId] = useState(null);
  const [groups, setGroups] = useState([]);
  const [selectedGroup, setSelectedGroup] = useState(null);
  const [unassigned, setUnassigned] = useState([]);
  const [showAddPicker, setShowAddPicker] = useState(false);
  const [newGroupName, setNewGroupName] = useState("");
  const [newYearName, setNewYearName] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const loadYears = useCallback(async () => {
    try {
      const res = await api.get("/years/mine");
      setYears(res.data);
      if (res.data.length > 0) setSelectedYearId(res.data[0].id);
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't load years.");
    } finally {
      setLoading(false);
    }
  }, []);

  const loadGroups = useCallback(async (yearId) => {
    if (!yearId) return;
    try {
      const res = await api.get(`/groups/year/${yearId}`);
      setGroups(res.data);
      setSelectedGroup(null);
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't load groups.");
    }
  }, []);

  const loadGroupDetail = useCallback(async (groupId) => {
    try {
      const res = await api.get(`/groups/${groupId}`);
      setSelectedGroup(res.data);
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't load group.");
    }
  }, []);

  const loadUnassigned = useCallback(async () => {
    try {
      const res = await api.get("/students/status/unassigned");
      setUnassigned(res.data);
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't load unassigned students.");
    }
  }, []);

  useEffect(() => { loadYears(); }, [loadYears]);
  useEffect(() => { loadGroups(selectedYearId); }, [selectedYearId, loadGroups]);

  async function handleCreateGroup() {
    if (!newGroupName.trim() || !selectedYearId) return;
    try {
      await api.post("/groups", { name: newGroupName.trim(), yearId: selectedYearId });
      setNewGroupName("");
      loadGroups(selectedYearId);
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't create group.");
    }
  }

  async function handleCreateYear() {
    if (!newYearName.trim()) return;
    try {
      await api.post("/years", { name: newYearName.trim() });
      setNewYearName("");
      loadYears();
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't create year.");
    }
  }

  async function handleAddStudent(studentId) {
    try {
      await api.post(`/groups/${selectedGroup.id}/students`, { studentId });
      setShowAddPicker(false);
      loadGroupDetail(selectedGroup.id);
      loadGroups(selectedYearId);
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't add student.");
    }
  }

  async function handleRemoveStudent(studentId) {
    try {
      await api.delete(`/groups/${selectedGroup.id}/students/${studentId}`);
      loadGroupDetail(selectedGroup.id);
      loadGroups(selectedYearId);
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't remove student.");
    }
  }

  if (loading) {
    return (
      <Screen scroll={false} style={{ alignItems: "center", justifyContent: "center" }}>
        <ActivityIndicator color={colors.primary} size="large" />
      </Screen>
    );
  }

  return (
    <Screen>
      {error ? (
        <Card style={{ marginBottom: spacing.md }}>
          <Text style={{ color: colors.danger }}>{error}</Text>
        </Card>
      ) : null}

      <View style={{ flexDirection: "row", marginBottom: spacing.sm }}>
        <TextInput
          value={newYearName}
          onChangeText={setNewYearName}
          placeholder="New year name (e.g. Year 1 - IGCSE)"
          placeholderTextColor={colors.textMuted}
          style={{ flex: 1, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.sm, marginRight: spacing.sm, backgroundColor: colors.white }}
        />
        <Button title="+ New year" variant="outline" onPress={handleCreateYear} />
      </View>

      {years.length === 0 ? (
        <Card style={{ marginBottom: spacing.md }}>
          <Text style={typography.body}>Create your first year above to get started — groups and everything else live inside a year.</Text>
        </Card>
      ) : null}

      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: spacing.xs, marginBottom: spacing.md }}>
        {years.map((y) => {
          const active = y.id === selectedYearId;
          return (
            <Pressable
              key={y.id}
              onPress={() => setSelectedYearId(y.id)}
              style={{
                backgroundColor: active ? colors.primary : colors.white,
                borderWidth: active ? 0 : 1,
                borderColor: colors.border,
                paddingVertical: spacing.sm,
                paddingHorizontal: spacing.md,
                borderRadius: radius.md,
              }}
            >
              <Text style={{ color: active ? colors.white : colors.textPrimary, fontWeight: "600", fontSize: 13 }}>
                {y.name}
              </Text>
            </Pressable>
          );
        })}
      </View>

      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: spacing.md }}>
        <View style={{ flex: 1, minWidth: 240 }}>
          <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: spacing.sm }}>
            <Text style={typography.h3}>Groups</Text>
          </View>

          <View style={{ flexDirection: "row", marginBottom: spacing.sm }}>
            <TextInput
              value={newGroupName}
              onChangeText={setNewGroupName}
              placeholder="New group name"
              placeholderTextColor={colors.textMuted}
              style={{ flex: 1, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.sm, marginRight: spacing.sm, backgroundColor: colors.white }}
            />
            <Button title="Add" variant="warning" onPress={handleCreateGroup} />
          </View>

          {groups.map((g) => {
            const active = selectedGroup?.id === g.id;
            return (
              <Pressable key={g.id} onPress={() => loadGroupDetail(g.id)}>
                <Card style={{ backgroundColor: active ? colors.primary : colors.white, marginBottom: spacing.sm }}>
                  <Text style={{ color: active ? colors.white : colors.textPrimary, fontWeight: "700", fontSize: 14 }}>{g.name}</Text>
                  <Text style={{ color: active ? "#C9D6D3" : colors.textMuted, fontSize: 12, marginTop: 2 }}>
                    {g._count?.members ?? 0} students
                  </Text>
                </Card>
              </Pressable>
            );
          })}
        </View>

        <View style={{ flex: 1.3, minWidth: 280 }}>
          {!selectedGroup ? (
            <Card><Text style={typography.body}>Select a group to view its roster.</Text></Card>
          ) : (
            <Card>
              <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" }}>
                <Text style={typography.h3}>{selectedGroup.name}</Text>
                <Button
                  title="+ Add student"
                  variant="secondary"
                  onPress={() => { setShowAddPicker(true); loadUnassigned(); }}
                />
              </View>
              <Text style={[typography.caption, { color: colors.textMuted, marginTop: 4, marginBottom: spacing.sm }]}>
                Assistants: {selectedGroup.assistantAssignments.map((a) => a.assistant.name).join(", ") || "None assigned"}
              </Text>

              {showAddPicker ? (
                <View style={{ marginBottom: spacing.md, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.sm }}>
                  <Text style={[typography.bodyBold, { marginBottom: spacing.xs }]}>Unassigned students</Text>
                  {unassigned.length === 0 ? (
                    <Text style={typography.caption}>No unassigned students.</Text>
                  ) : (
                    unassigned.map((s) => (
                      <Pressable key={s.id} onPress={() => handleAddStudent(s.id)} style={{ paddingVertical: spacing.xs }}>
                        <Text style={{ color: colors.primary }}>{s.name}</Text>
                      </Pressable>
                    ))
                  )}
                  <Button title="Cancel" variant="outline" onPress={() => setShowAddPicker(false)} style={{ marginTop: spacing.sm }} />
                </View>
              ) : null}

              <Text style={[typography.bodyBold, { marginBottom: spacing.sm }]}>
                Students ({selectedGroup.members.length})
              </Text>
              <ScrollView style={{ maxHeight: 320 }}>
                {selectedGroup.members.map((m) => (
                  <View key={m.id} style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingVertical: spacing.xs, borderBottomWidth: 1, borderBottomColor: colors.background }}>
                    <Text style={typography.body}>{m.student.name}</Text>
                    <Pressable onPress={() => handleRemoveStudent(m.student.id)}>
                      <Text style={{ color: colors.danger, fontSize: 16 }}>✕</Text>
                    </Pressable>
                  </View>
                ))}
              </ScrollView>
            </Card>
          )}
        </View>
      </View>
    </Screen>
  );
}

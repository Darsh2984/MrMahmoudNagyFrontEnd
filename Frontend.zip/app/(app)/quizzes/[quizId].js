import React, { useEffect, useState } from "react";
import { View, Text, Pressable, ActivityIndicator, Linking } from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import * as DocumentPicker from "expo-document-picker";
import { Screen } from "../../../src/components/layout/Screen";
import { Card } from "../../../src/components/ui/Card";
import { Button } from "../../../src/components/ui/Button";
import api from "../../../src/lib/api";
import { colors, spacing, radius, typography } from "../../../src/theme";

const OPTIONS = ["A", "B", "C", "D"];

export default function TakeQuiz() {
  const { quizId } = useLocalSearchParams();
  const router = useRouter();
  const [quiz, setQuiz] = useState(null);
  const [index, setIndex] = useState(0);
  const [answered, setAnswered] = useState({}); // questionId -> true once answered
  const [saving, setSaving] = useState(false);
  const [submitted, setSubmitted] = useState(null); // holds submission result once submitted
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    (async () => {
      try {
        await api.post(`/quiz-student/${quizId}/start`);
        const res = await api.get(`/quiz-student/${quizId}/take`);
        setQuiz(res.data);
      } catch (err) {
        setError(err.response?.data?.msg || "Couldn't load quiz.");
      } finally {
        setLoading(false);
      }
    })();
  }, [quizId]);

  async function answerMCQ(questionId, letter) {
    setSaving(true);
    try {
      await api.post(`/quiz-student/${quizId}/questions/${questionId}/answer`, { answerText: letter });
      setAnswered((a) => ({ ...a, [questionId]: true }));
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't save answer.");
    } finally {
      setSaving(false);
    }
  }

  async function answerWritten(questionId) {
    const result = await DocumentPicker.getDocumentAsync({ type: ["image/*", "application/pdf"] });
    if (result.canceled) return;
    const file = result.assets[0];
    const formData = new FormData();
    formData.append("file", { uri: file.uri, name: file.name, type: file.mimeType || "image/jpeg" });

    setSaving(true);
    try {
      await api.post(`/quiz-student/${quizId}/questions/${questionId}/answer`, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      setAnswered((a) => ({ ...a, [questionId]: true }));
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't upload answer.");
    } finally {
      setSaving(false);
    }
  }

  async function handleSubmit() {
    setSaving(true);
    try {
      const res = await api.post(`/quiz-student/${quizId}/submit`);
      setSubmitted(res.data.submission);
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't submit quiz.");
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <Screen scroll={false} style={{ alignItems: "center", justifyContent: "center" }}>
        <ActivityIndicator color={colors.primary} size="large" />
      </Screen>
    );
  }

  if (submitted) {
    return (
      <Screen scroll={false} style={{ alignItems: "center", justifyContent: "center" }}>
        <Card style={{ alignItems: "center", maxWidth: 360 }}>
          <Text style={[typography.h2, { color: colors.primary, marginBottom: spacing.sm }]}>Quiz submitted</Text>
          <Text style={[typography.body, { textAlign: "center", marginBottom: spacing.md }]}>
            Score so far: {submitted.score} / {quiz.questions.length}
            {"\n"}Written answers show as ungraded until reviewed.
          </Text>
          <Button title="Back to quizzes" onPress={() => router.replace("/(app)/quizzes")} />
        </Card>
      </Screen>
    );
  }

  const question = quiz?.questions[index];
  const total = quiz?.questions.length || 0;
  const isAnswered = question && answered[question.id];

  return (
    <Screen>
      {error ? <Card style={{ marginBottom: spacing.md }}><Text style={{ color: colors.danger }}>{error}</Text></Card> : null}

      <Text style={[typography.caption, { color: colors.textMuted, marginBottom: spacing.xs }]}>
        Question {index + 1} of {total}
      </Text>
      <Text style={[typography.h2, { color: colors.primary, marginBottom: spacing.md }]}>{quiz?.title}</Text>

      {question ? (
        <Card style={{ marginBottom: spacing.md }}>
          <Text style={[typography.bodyBold, { marginBottom: spacing.sm }]}>
            {question.type === "MCQ" ? "Multiple choice" : "Written question"}
          </Text>
          <Pressable onPress={() => Linking.openURL(question.questionFileUrl)} style={{ marginBottom: spacing.md }}>
            <Text style={{ color: colors.primary, fontWeight: "600" }}>📄 View question</Text>
          </Pressable>

          {question.type === "MCQ" ? (
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: spacing.sm }}>
              {OPTIONS.map((letter) => (
                <Pressable key={letter} onPress={() => answerMCQ(question.id, letter)}
                  style={{ paddingVertical: spacing.sm, paddingHorizontal: spacing.md, borderRadius: radius.md, backgroundColor: colors.white, borderWidth: 1, borderColor: colors.border }}>
                  <Text style={{ fontWeight: "700", color: colors.textPrimary }}>{letter}</Text>
                </Pressable>
              ))}
            </View>
          ) : (
            <Button title="Upload photo of your answer" variant="secondary" onPress={() => answerWritten(question.id)} loading={saving} />
          )}

          {isAnswered ? <Text style={{ color: colors.secondary, marginTop: spacing.sm, fontWeight: "600" }}>✓ Answer saved</Text> : null}
        </Card>
      ) : null}

      <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
        <Button title="Previous" variant="outline" disabled={index === 0} onPress={() => setIndex((i) => i - 1)} />
        {index < total - 1 ? (
          <Button title="Next" onPress={() => setIndex((i) => i + 1)} />
        ) : (
          <Button title="Submit quiz" variant="warning" onPress={handleSubmit} loading={saving} />
        )}
      </View>
    </Screen>
  );
}

import React, { useEffect, useState, useCallback } from "react";
import { View, Text, Pressable, TextInput, ActivityIndicator } from "react-native";
import { useRouter } from "expo-router";
import { Screen } from "../../src/components/layout/Screen";
import { Card } from "../../src/components/ui/Card";
import { Button } from "../../src/components/ui/Button";
import { Badge } from "../../src/components/ui/Badge";
import { useAuth } from "../../src/contexts/AuthContext";
import api from "../../src/lib/api";
import { colors, spacing, radius, typography } from "../../src/theme";

const STATUS_TONE = {
  OPEN: "danger",
  RESOLVED_PENDING_CONFIRM: "warning",
  CONFIRMED_RESOLVED: "success",
  REOPENED: "danger",
};

export default function Tickets() {
  const { user } = useAuth();
  const router = useRouter();
  const isStudent = user?.role === "STUDENT";
  const isAdminLevel = user?.role === "TEACHER" || user?.isHeadAssistant;

  const [tickets, setTickets] = useState([]);
  const [categories, setCategories] = useState([]);
  const [showNew, setShowNew] = useState(false);
  const [categoryId, setCategoryId] = useState(null);
  const [subject, setSubject] = useState("");
  const [firstMessage, setFirstMessage] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    setError("");
    try {
      if (isStudent) {
        const res = await api.get("/tickets/mine");
        setTickets(res.data);
      } else if (isAdminLevel) {
        const res = await api.get("/tickets/all");
        setTickets(res.data);
      } else {
        const res = await api.get("/tickets/assigned-to-me");
        setTickets(res.data);
      }
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't load tickets.");
    } finally {
      setLoading(false);
    }
  }, [isStudent, isAdminLevel]);

  useEffect(() => {
    load();
    if (isStudent) {
      api.get("/ticket-categories").then((res) => {
        setCategories(res.data);
        if (res.data.length) setCategoryId(res.data[0].id);
      }).catch(() => {});
    }
  }, [load, isStudent]);

  async function handleCreate() {
    if (!subject.trim() || !categoryId) return;
    try {
      const res = await api.post("/tickets", { categoryId, subject: subject.trim(), firstMessage: firstMessage.trim() });
      setShowNew(false);
      setSubject("");
      setFirstMessage("");
      router.push(`/(app)/tickets/${res.data.ticket.id}`);
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't create ticket.");
    }
  }

  if (loading) {
    return (
      <Screen scroll={false} style={{ alignItems: "center", justifyContent: "center" }}>
        <ActivityIndicator color={colors.primary} size="large" />
      </Screen>
    );
  }

  return (
    <Screen>
      {error ? <Card style={{ marginBottom: spacing.md }}><Text style={{ color: colors.danger }}>{error}</Text></Card> : null}

      <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: spacing.md }}>
        <Text style={[typography.h1, { color: colors.primary }]}>Tickets</Text>
        {isStudent ? <Button title="+ New ticket" variant="warning" onPress={() => setShowNew((s) => !s)} /> : null}
      </View>

      {showNew ? (
        <Card style={{ marginBottom: spacing.md }}>
          <Text style={[typography.bodyBold, { marginBottom: spacing.sm }]}>New ticket</Text>
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: spacing.xs, marginBottom: spacing.sm }}>
            {categories.map((c) => (
              <Pressable key={c.id} onPress={() => setCategoryId(c.id)}
                style={{ backgroundColor: c.id === categoryId ? colors.primary : colors.white, borderWidth: c.id === categoryId ? 0 : 1, borderColor: colors.border, padding: spacing.sm, borderRadius: radius.md }}>
                <Text style={{ color: c.id === categoryId ? colors.white : colors.textPrimary, fontSize: 12, fontWeight: "600" }}>{c.name}</Text>
              </Pressable>
            ))}
          </View>
          <TextInput value={subject} onChangeText={setSubject} placeholder="Subject" placeholderTextColor={colors.textMuted}
            style={{ borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.sm, marginBottom: spacing.sm, backgroundColor: colors.white }} />
          <TextInput value={firstMessage} onChangeText={setFirstMessage} placeholder="Describe your issue..." placeholderTextColor={colors.textMuted}
            multiline style={{ borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.sm, marginBottom: spacing.sm, backgroundColor: colors.white, minHeight: 70 }} />
          <Button title="Submit" onPress={handleCreate} />
        </Card>
      ) : null}

      {tickets.length === 0 ? (
        <Card><Text style={typography.body}>No tickets yet.</Text></Card>
      ) : (
        tickets.map((t) => (
          <Pressable key={t.id} onPress={() => router.push(`/(app)/tickets/${t.id}`)}>
            <Card style={{ marginBottom: spacing.sm, flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
              <View style={{ flex: 1 }}>
                <Text style={typography.bodyBold}>{t.subject}</Text>
                <Text style={[typography.caption, { color: colors.textMuted, marginTop: 2 }]}>
                  {t.category?.name} {t.createdBy ? `· ${t.createdBy.name}` : ""}
                </Text>
              </View>
              <Badge label={t.status.replace(/_/g, " ")} tone={STATUS_TONE[t.status] || "neutral"} />
            </Card>
          </Pressable>
        ))
      )}
    </Screen>
  );
}

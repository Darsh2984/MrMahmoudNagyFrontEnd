import React, { useEffect, useState, useRef, useCallback } from "react";
import { View, Text, TextInput, ScrollView, ActivityIndicator, KeyboardAvoidingView, Platform } from "react-native";
import { useLocalSearchParams } from "expo-router";
import { Screen } from "../../../src/components/layout/Screen";
import { Card } from "../../../src/components/ui/Card";
import { Button } from "../../../src/components/ui/Button";
import { Badge } from "../../../src/components/ui/Badge";
import { useAuth } from "../../../src/contexts/AuthContext";
import api from "../../../src/lib/api";
import { socket } from "../../../src/lib/socket";
import { colors, spacing, radius, typography } from "../../../src/theme";

export default function TicketThread() {
  const { ticketId } = useLocalSearchParams();
  const { user } = useAuth();
  const [ticket, setTicket] = useState(null);
  const [messages, setMessages] = useState([]);
  const [content, setContent] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const scrollRef = useRef(null);

  const load = useCallback(async () => {
    try {
      const res = await api.get(`/tickets/${ticketId}`);
      setTicket(res.data);
      setMessages(res.data.messages);
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't load ticket.");
    } finally {
      setLoading(false);
    }
  }, [ticketId]);

  useEffect(() => {
    load();
    socket.connect();
    socket.emit("join-ticket", { ticketId });
    const onMessage = (msg) => {
      if (msg.ticketId === ticketId) setMessages((m) => [...m, msg]);
    };
    socket.on("new-ticket-message", onMessage);
    return () => {
      socket.emit("leave-ticket", { ticketId });
      socket.off("new-ticket-message", onMessage);
      socket.disconnect();
    };
  }, [ticketId, load]);

  useEffect(() => {
    scrollRef.current?.scrollToEnd({ animated: true });
  }, [messages]);

  async function sendMessage() {
    if (!content.trim()) return;
    const text = content.trim();
    setContent("");
    try {
      await api.post(`/tickets/${ticketId}/messages`, { content: text });
      // Real-time echo comes back over the socket, no need to append locally.
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't send message.");
    }
  }

  async function markResolved() {
    try {
      await api.patch(`/tickets/${ticketId}/resolve`);
      load();
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't update ticket.");
    }
  }

  async function confirmResolution(resolved) {
    try {
      await api.patch(`/tickets/${ticketId}/confirm`, { resolved });
      load();
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't confirm.");
    }
  }

  if (loading) {
    return (
      <Screen scroll={false} style={{ alignItems: "center", justifyContent: "center" }}>
        <ActivityIndicator color={colors.primary} size="large" />
      </Screen>
    );
  }

  const isStudent = user?.role === "STUDENT";
  const isAssignedAssistant = ticket?.assignedAssistant?.id === user?.id || user?.role === "TEACHER" || user?.isHeadAssistant;

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : undefined}>
      <View style={{ flex: 1, backgroundColor: colors.background }}>
        <View style={{ padding: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.border, backgroundColor: colors.white }}>
          <Text style={typography.h3}>{ticket?.subject}</Text>
          {error ? <Text style={{ color: colors.danger, marginTop: 4 }}>{error}</Text> : null}
          <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: spacing.xs }}>
            <Badge label={ticket?.status.replace(/_/g, " ")} tone={ticket?.status === "CONFIRMED_RESOLVED" ? "success" : "warning"} />
            {isAssignedAssistant && ticket?.status === "OPEN" ? (
              <Button title="Mark resolved" variant="secondary" onPress={markResolved} />
            ) : null}
          </View>
          {isStudent && ticket?.status === "RESOLVED_PENDING_CONFIRM" ? (
            <View style={{ flexDirection: "row", gap: spacing.sm, marginTop: spacing.sm }}>
              <Text style={[typography.body, { flex: 1 }]}>Was this actually solved?</Text>
              <Button title="Yes" variant="secondary" onPress={() => confirmResolution(true)} />
              <Button title="No" variant="danger" onPress={() => confirmResolution(false)} />
            </View>
          ) : null}
        </View>

        <ScrollView ref={scrollRef} style={{ flex: 1, padding: spacing.md }}>
          {messages.map((m) => {
            const mine = m.senderId === user?.id;
            return (
              <View key={m.id} style={{ alignItems: mine ? "flex-end" : "flex-start", marginBottom: spacing.sm }}>
                <View style={{ backgroundColor: mine ? colors.primary : colors.white, borderWidth: mine ? 0 : 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.sm, maxWidth: "80%" }}>
                  <Text style={{ color: mine ? colors.white : colors.textPrimary }}>{m.content}</Text>
                </View>
              </View>
            );
          })}
        </ScrollView>

        <View style={{ flexDirection: "row", padding: spacing.sm, borderTopWidth: 1, borderTopColor: colors.border, backgroundColor: colors.white }}>
          <TextInput
            value={content}
            onChangeText={setContent}
            placeholder="Type a message..."
            placeholderTextColor={colors.textMuted}
            style={{ flex: 1, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.sm, marginRight: spacing.sm }}
          />
          <Button title="Send" onPress={sendMessage} />
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}

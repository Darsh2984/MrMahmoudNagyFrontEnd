import React, { useEffect, useState, useCallback } from "react";
import { View, Text, Pressable, ActivityIndicator, TextInput } from "react-native";
import { useLocalSearchParams, Linking } from "expo-router";
import { Screen } from "../../../src/components/layout/Screen";
import { Card } from "../../../src/components/ui/Card";
import { Button } from "../../../src/components/ui/Button";
import { Badge } from "../../../src/components/ui/Badge";
import api from "../../../src/lib/api";
import { formatDate } from "../../../src/utils/formatDate";
import { colors, spacing, radius, typography } from "../../../src/theme";

export default function TaskDetail() {
  const { taskId } = useLocalSearchParams();
  const [task, setTask] = useState(null);
  const [assistants, setAssistants] = useState([]);
  const [pickerForSubmission, setPickerForSubmission] = useState(null);
  const [gradeInputs, setGradeInputs] = useState({}); // submissionId -> grade text
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    try {
      const res = await api.get(`/tasks/${taskId}`);
      setTask(res.data);
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't load task.");
    } finally {
      setLoading(false);
    }
  }, [taskId]);

  useEffect(() => {
    load();
    api.get("/auth/assistants").then((res) => setAssistants(res.data)).catch(() => {});
  }, [load]);

  async function delegate(submissionId, assistantId) {
    try {
      await api.post("/delegations", { submissionId, assistantId });
      setPickerForSubmission(null);
      load();
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't delegate.");
    }
  }

  async function gradeDirectly(submissionId) {
    const grade = parseFloat(gradeInputs[submissionId]);
    if (isNaN(grade)) { setError("Enter a valid grade."); return; }
    try {
      await api.patch(`/submissions/${submissionId}/grade`, { grade });
      load();
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't save grade.");
    }
  }

  if (loading) {
    return (
      <Screen scroll={false} style={{ alignItems: "center", justifyContent: "center" }}>
        <ActivityIndicator color={colors.primary} size="large" />
      </Screen>
    );
  }

  return (
    <Screen>
      {error ? <Card style={{ marginBottom: spacing.md }}><Text style={{ color: colors.danger }}>{error}</Text></Card> : null}

      <Text style={[typography.h1, { color: colors.primary }]}>{task?.title}</Text>
      <Text style={[typography.body, { color: colors.textMuted, marginTop: spacing.xs, marginBottom: spacing.sm }]}>{task?.description}</Text>
      <View style={{ flexDirection: "row", gap: spacing.sm, marginBottom: spacing.lg }}>
        <Badge label={`Due ${formatDate(task?.deadline)}`} tone="neutral" />
        <Badge label={task?.allowLateSubmission ? "Late OK" : "No late"} tone={task?.allowLateSubmission ? "success" : "danger"} />
        {task?.taskFileUrl ? (
          <Pressable onPress={() => Linking.openURL(task.taskFileUrl)}>
            <Badge label="📎 Homework PDF" tone="info" />
          </Pressable>
        ) : null}
      </View>

      <Text style={[typography.h3, { marginBottom: spacing.sm }]}>Submissions ({task?.submissions.length})</Text>
      {task?.submissions.length === 0 ? (
        <Card><Text style={typography.body}>No submissions yet.</Text></Card>
      ) : (
        task.submissions.map((s) => (
          <Card key={s.id} style={{ marginBottom: spacing.sm }}>
            <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: spacing.xs }}>
              <Text style={typography.bodyBold}>{s.student.name}</Text>
              {s.grade != null ? (
                <Badge label={`Graded: ${s.grade}`} tone="success" />
              ) : s.delegation ? (
                <Badge label={`Delegated to ${s.delegation.assistant.name}`} tone="warning" />
              ) : (
                <Badge label="Ungraded" tone="neutral" />
              )}
            </View>

            {s.fileUrl ? (
              <Pressable onPress={() => Linking.openURL(s.fileUrl)}>
                <Text style={{ color: colors.primary, marginBottom: spacing.sm }}>View submission file</Text>
              </Pressable>
            ) : null}

            {s.grade == null && !s.delegation ? (
              <View>
                <View style={{ flexDirection: "row", gap: spacing.sm, marginBottom: spacing.sm }}>
                  <TextInput
                    value={gradeInputs[s.id] || ""}
                    onChangeText={(v) => setGradeInputs((g) => ({ ...g, [s.id]: v }))}
                    placeholder="Grade"
                    keyboardType="numeric"
                    placeholderTextColor={colors.textMuted}
                    style={{ flex: 1, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.sm, backgroundColor: colors.white }}
                  />
                  <Button title="Grade" variant="secondary" onPress={() => gradeDirectly(s.id)} />
                </View>
                <Button title="Delegate to assistant" variant="outline" onPress={() => setPickerForSubmission(s.id)} />
                {pickerForSubmission === s.id ? (
                  <View style={{ flexDirection: "row", flexWrap: "wrap", gap: spacing.xs, marginTop: spacing.sm }}>
                    {assistants.map((a) => (
                      <Pressable key={a.id} onPress={() => delegate(s.id, a.id)}
                        style={{ borderWidth: 1, borderColor: colors.border, padding: spacing.sm, borderRadius: radius.md, backgroundColor: colors.white }}>
                        <Text style={{ fontSize: 12, color: colors.textPrimary }}>{a.name}</Text>
                      </Pressable>
                    ))}
                  </View>
                ) : null}
              </View>
            ) : null}
          </Card>
        ))
      )}
    </Screen>
  );
}

import React, { useEffect, useState, useCallback } from "react";
import { View, Text, Pressable, TextInput, ActivityIndicator } from "react-native";
import { useRouter } from "expo-router";
import * as DocumentPicker from "expo-document-picker";
import { Screen } from "../../src/components/layout/Screen";
import { Card } from "../../src/components/ui/Card";
import { Button } from "../../src/components/ui/Button";
import { Badge } from "../../src/components/ui/Badge";
import api from "../../src/lib/api";
import { formatDate } from "../../src/utils/formatDate";
import { colors, spacing, radius, typography } from "../../src/theme";

export default function Tasks() {
  const router = useRouter();
  const [years, setYears] = useState([]);
  const [yearId, setYearId] = useState(null);
  const [groups, setGroups] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [selectedGroupIds, setSelectedGroupIds] = useState([]);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [deadline, setDeadline] = useState("");
  const [gradeOutOf, setGradeOutOf] = useState("100");
  const [allowLate, setAllowLate] = useState(true);
  const [taskFile, setTaskFile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const loadTasksForYear = useCallback(async (grps) => {
    const seen = new Map();
    for (const g of grps) {
      try {
        const res = await api.get(`/tasks/group/${g.id}`);
        res.data.forEach((t) => seen.set(t.id, t));
      } catch (e) { /* ignore per-group failure */ }
    }
    setTasks(Array.from(seen.values()));
  }, []);

  useEffect(() => {
    (async () => {
      try {
        const res = await api.get("/years/mine");
        setYears(res.data);
        if (res.data.length) setYearId(res.data[0].id);
      } catch (err) {
        setError(err.response?.data?.msg || "Couldn't load years.");
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  useEffect(() => {
    if (!yearId) return;
    api.get(`/groups/year/${yearId}`).then((res) => {
      setGroups(res.data);
      loadTasksForYear(res.data);
    }).catch(() => {});
  }, [yearId, loadTasksForYear]);

  function toggleGroup(id) {
    setSelectedGroupIds((list) => (list.includes(id) ? list.filter((x) => x !== id) : [...list, id]));
  }

  async function pickFile() {
    const result = await DocumentPicker.getDocumentAsync({ type: "application/pdf" });
    if (!result.canceled) setTaskFile(result.assets[0]);
  }

  async function handleCreate() {
    if (!title.trim() || !deadline.trim() || selectedGroupIds.length === 0) {
      setError("Title, deadline, and at least one group are required.");
      return;
    }
    const formData = new FormData();
    formData.append("title", title.trim());
    formData.append("description", description.trim());
    formData.append("yearId", yearId);
    formData.append("deadline", deadline.trim());
    formData.append("gradeOutOf", gradeOutOf);
    formData.append("allowLateSubmission", String(allowLate));
    formData.append("groupIds", JSON.stringify(selectedGroupIds));
    if (taskFile) {
      formData.append("file", { uri: taskFile.uri, name: taskFile.name, type: taskFile.mimeType || "application/pdf" });
    }
    try {
      await api.post("/tasks", formData, { headers: { "Content-Type": "multipart/form-data" } });
      setTitle(""); setDescription(""); setDeadline(""); setGradeOutOf("100"); setAllowLate(true); setTaskFile(null); setSelectedGroupIds([]);
      const res = await api.get(`/groups/year/${yearId}`);
      loadTasksForYear(res.data);
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't create task.");
    }
  }

  if (loading) {
    return (
      <Screen scroll={false} style={{ alignItems: "center", justifyContent: "center" }}>
        <ActivityIndicator color={colors.primary} size="large" />
      </Screen>
    );
  }

  return (
    <Screen>
      <Text style={[typography.h1, { color: colors.primary, marginBottom: spacing.md }]}>Tasks</Text>
      {error ? <Card style={{ marginBottom: spacing.md }}><Text style={{ color: colors.danger }}>{error}</Text></Card> : null}

      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: spacing.xs, marginBottom: spacing.md }}>
        {years.map((y) => (
          <Pressable key={y.id} onPress={() => setYearId(y.id)}
            style={{ backgroundColor: y.id === yearId ? colors.primary : colors.white, borderWidth: y.id === yearId ? 0 : 1, borderColor: colors.border, padding: spacing.sm, borderRadius: radius.md }}>
            <Text style={{ color: y.id === yearId ? colors.white : colors.textPrimary, fontSize: 13, fontWeight: "600" }}>{y.name}</Text>
          </Pressable>
        ))}
      </View>

      <Card style={{ marginBottom: spacing.lg }}>
        <Text style={[typography.bodyBold, { marginBottom: spacing.sm }]}>New task</Text>
        <TextInput value={title} onChangeText={setTitle} placeholder="Title" placeholderTextColor={colors.textMuted}
          style={{ borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.sm, marginBottom: spacing.sm, backgroundColor: colors.white }} />
        <TextInput value={description} onChangeText={setDescription} placeholder="Description / instructions" multiline placeholderTextColor={colors.textMuted}
          style={{ borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.sm, marginBottom: spacing.sm, backgroundColor: colors.white, minHeight: 60 }} />
        <View style={{ flexDirection: "row", gap: spacing.sm, marginBottom: spacing.sm }}>
          <TextInput value={deadline} onChangeText={setDeadline} placeholder="Deadline (YYYY-MM-DD)" placeholderTextColor={colors.textMuted}
            style={{ flex: 1, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.sm, backgroundColor: colors.white }} />
          <TextInput value={gradeOutOf} onChangeText={setGradeOutOf} placeholder="Grade out of" keyboardType="numeric" placeholderTextColor={colors.textMuted}
            style={{ flex: 1, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.sm, backgroundColor: colors.white }} />
        </View>

        <Pressable onPress={pickFile} style={{ backgroundColor: "#EDE9E2", borderRadius: radius.md, padding: spacing.sm, alignItems: "center", marginBottom: spacing.sm }}>
          <Text style={{ color: colors.textPrimary, fontSize: 13 }}>📎 {taskFile ? taskFile.name : "Attach homework PDF (optional)"}</Text>
        </Pressable>

        <Pressable onPress={() => setAllowLate((v) => !v)}
          style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", backgroundColor: colors.background, borderRadius: radius.md, padding: spacing.sm, marginBottom: spacing.sm }}>
          <Text style={{ fontSize: 13, color: colors.textPrimary }}>Allow late submissions</Text>
          <View style={{ width: 36, height: 20, borderRadius: 999, backgroundColor: allowLate ? colors.secondary : colors.border, justifyContent: "center" }}>
            <View style={{ width: 16, height: 16, borderRadius: 999, backgroundColor: colors.white, marginLeft: allowLate ? 18 : 2 }} />
          </View>
        </Pressable>

        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: spacing.xs, marginBottom: spacing.sm }}>
          {groups.map((g) => {
            const on = selectedGroupIds.includes(g.id);
            return (
              <Pressable key={g.id} onPress={() => toggleGroup(g.id)}
                style={{ backgroundColor: on ? colors.secondary : colors.white, borderWidth: on ? 0 : 1, borderColor: colors.border, padding: spacing.sm, borderRadius: radius.md }}>
                <Text style={{ color: on ? colors.white : colors.textPrimary, fontSize: 12, fontWeight: "600" }}>{g.name}</Text>
              </Pressable>
            );
          })}
        </View>
        <Button title="Create task" variant="warning" onPress={handleCreate} />
      </Card>

      {tasks.length === 0 ? (
        <Card><Text style={typography.body}>No tasks yet.</Text></Card>
      ) : (
        tasks.map((t) => (
          <Card key={t.id} style={{ marginBottom: spacing.sm }}>
            <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
              <View>
                <Text style={typography.bodyBold}>{t.title}</Text>
                <Text style={[typography.caption, { color: colors.textMuted, marginTop: 2 }]}>
                  Due {formatDate(t.deadline)}
                </Text>
              </View>
              <View style={{ flexDirection: "row", alignItems: "center", gap: spacing.sm }}>
                <Badge label={t.allowLateSubmission ? "Late OK" : "No late"} tone={t.allowLateSubmission ? "success" : "danger"} />
                <Pressable onPress={() => router.push(`/(app)/tasks/${t.id}`)}>
                  <Text style={{ color: colors.primary, fontWeight: "600" }}>View →</Text>
                </Pressable>
              </View>
            </View>
          </Card>
        ))
      )}
    </Screen>
  );
}

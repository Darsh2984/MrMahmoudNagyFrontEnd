import React, { useEffect, useState } from "react";
import { View, Text, Pressable, ActivityIndicator, TextInput } from "react-native";
import { useRouter } from "expo-router";
import { Screen } from "../../src/components/layout/Screen";
import { Card } from "../../src/components/ui/Card";
import { Badge } from "../../src/components/ui/Badge";
import { Button } from "../../src/components/ui/Button";
import { useAuth } from "../../src/contexts/AuthContext";
import api from "../../src/lib/api";
import { colors, spacing, typography } from "../../src/theme";

function TeacherQuizManager() {
  const [years, setYears] = useState([]);
  const [yearId, setYearId] = useState(null);
  const [groups, setGroups] = useState([]);
  const [questions, setQuestions] = useState([]);
  const [quizzes, setQuizzes] = useState([]);
  const [title, setTitle] = useState("");
  const [duration, setDuration] = useState("30");
  const [selectedGroupIds, setSelectedGroupIds] = useState([]);
  const [selectedQuestionIds, setSelectedQuestionIds] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    (async () => {
      try {
        const [yearsRes, questionsRes, quizzesRes] = await Promise.all([
          api.get("/years/mine"),
          api.get("/questions"),
          api.get("/quiz/teacher"),
        ]);
        setYears(yearsRes.data);
        setQuestions(questionsRes.data);
        setQuizzes(quizzesRes.data);
        if (yearsRes.data.length) setYearId(yearsRes.data[0].id);
      } catch (err) {
        setError(err.response?.data?.msg || "Couldn't load data.");
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  useEffect(() => {
    if (!yearId) return;
    api.get(`/groups/year/${yearId}`).then((res) => setGroups(res.data)).catch(() => {});
  }, [yearId]);

  function toggle(list, setList, id) {
    setList(list.includes(id) ? list.filter((x) => x !== id) : [...list, id]);
  }

  async function handleCreateQuiz() {
    if (!title.trim() || selectedGroupIds.length === 0 || selectedQuestionIds.length === 0) {
      setError("Title, at least one group, and at least one question are required.");
      return;
    }
    try {
      await api.post("/quiz", {
        title: title.trim(),
        duration: parseInt(duration, 10) || 30,
        groupIds: selectedGroupIds,
        questionIds: selectedQuestionIds,
      });
      setTitle("");
      setSelectedGroupIds([]);
      setSelectedQuestionIds([]);
      const res = await api.get("/quiz/teacher");
      setQuizzes(res.data);
    } catch (err) {
      setError(err.response?.data?.msg || "Couldn't create quiz.");
    }
  }

  if (loading) {
    return (
      <Screen scroll={false} style={{ alignItems: "center", justifyContent: "center" }}>
        <ActivityIndicator color={colors.primary} size="large" />
      </Screen>
    );
  }

  return (
    <Screen>
      <Text style={[typography.h1, { color: colors.primary, marginBottom: spacing.md }]}>Quizzes</Text>
      {error ? <Card style={{ marginBottom: spacing.md }}><Text style={{ color: colors.danger }}>{error}</Text></Card> : null}

      <Card style={{ marginBottom: spacing.lg }}>
        <Text style={[typography.h3, { marginBottom: spacing.sm }]}>New quiz</Text>

        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: spacing.xs, marginBottom: spacing.sm }}>
          {years.map((y) => (
            <Pressable key={y.id} onPress={() => setYearId(y.id)}
              style={{ backgroundColor: y.id === yearId ? colors.primary : colors.white, borderWidth: y.id === yearId ? 0 : 1, borderColor: colors.border, padding: spacing.sm, borderRadius: 8 }}>
              <Text style={{ color: y.id === yearId ? colors.white : colors.textPrimary, fontSize: 12, fontWeight: "600" }}>{y.name}</Text>
            </Pressable>
          ))}
        </View>

        <TextInput value={title} onChangeText={setTitle} placeholder="Quiz title" placeholderTextColor={colors.textMuted}
          style={{ borderWidth: 1, borderColor: colors.border, borderRadius: 8, padding: spacing.sm, marginBottom: spacing.sm, backgroundColor: colors.white }} />
        <TextInput value={duration} onChangeText={setDuration} placeholder="Duration (minutes)" keyboardType="numeric" placeholderTextColor={colors.textMuted}
          style={{ borderWidth: 1, borderColor: colors.border, borderRadius: 8, padding: spacing.sm, marginBottom: spacing.sm, backgroundColor: colors.white }} />

        <Text style={[typography.bodyBold, { marginBottom: spacing.xs }]}>Groups</Text>
        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: spacing.xs, marginBottom: spacing.sm }}>
          {groups.map((g) => {
            const on = selectedGroupIds.includes(g.id);
            return (
              <Pressable key={g.id} onPress={() => toggle(selectedGroupIds, setSelectedGroupIds, g.id)}
                style={{ backgroundColor: on ? colors.secondary : colors.white, borderWidth: on ? 0 : 1, borderColor: colors.border, padding: spacing.sm, borderRadius: 8 }}>
                <Text style={{ color: on ? colors.white : colors.textPrimary, fontSize: 12, fontWeight: "600" }}>{g.name}</Text>
              </Pressable>
            );
          })}
        </View>

        <Text style={[typography.bodyBold, { marginBottom: spacing.xs }]}>Questions ({selectedQuestionIds.length} selected)</Text>
        <View style={{ maxHeight: 200 }}>
          {questions.map((q) => {
            const on = selectedQuestionIds.includes(q.id);
            return (
              <Pressable key={q.id} onPress={() => toggle(selectedQuestionIds, setSelectedQuestionIds, q.id)}
                style={{ flexDirection: "row", justifyContent: "space-between", paddingVertical: spacing.xs, borderBottomWidth: 1, borderBottomColor: colors.background }}>
                <Text style={{ color: on ? colors.secondary : colors.textPrimary, fontWeight: on ? "700" : "400" }}>
                  {on ? "✓ " : ""}{q.type} question
                </Text>
              </Pressable>
            );
          })}
        </View>

        <Button title="Create quiz" variant="warning" onPress={handleCreateQuiz} style={{ marginTop: spacing.sm }} />
      </Card>

      <Text style={[typography.h3, { marginBottom: spacing.sm }]}>Existing quizzes</Text>
      {quizzes.length === 0 ? (
        <Card><Text style={typography.body}>No quizzes yet.</Text></Card>
      ) : (
        quizzes.map((q) => (
          <Card key={q.id} style={{ marginBottom: spacing.sm }}>
            <Text style={typography.bodyBold}>{q.title}</Text>
            <Text style={[typography.caption, { color: colors.textMuted, marginTop: 2 }]}>
              Groups: {q.groups.map((g) => g.group.name).join(", ")}
            </Text>
          </Card>
        ))
      )}
    </Screen>
  );
}

export default function Quizzes() {

  const { user } = useAuth();
  const router = useRouter();
  const [quizzes, setQuizzes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    if (user?.role !== "STUDENT") { setLoading(false); return; }
    api.get("/quiz-student/mine")
      .then((res) => setQuizzes(res.data))
      .catch((err) => setError(err.response?.data?.msg || "Couldn't load quizzes."))
      .finally(() => setLoading(false));
  }, [user]);

  if (user?.role !== "STUDENT") {
    return <TeacherQuizManager />;
  }

  if (loading) {
    return (
      <Screen scroll={false} style={{ alignItems: "center", justifyContent: "center" }}>
        <ActivityIndicator color={colors.primary} size="large" />
      </Screen>
    );
  }

  return (
    <Screen>
      <Text style={[typography.h1, { color: colors.primary, marginBottom: spacing.md }]}>Quizzes</Text>
      {error ? <Card style={{ marginBottom: spacing.md }}><Text style={{ color: colors.danger }}>{error}</Text></Card> : null}
      {quizzes.length === 0 ? (
        <Card><Text style={typography.body}>No quizzes assigned yet.</Text></Card>
      ) : (
        quizzes.map((q) => (
          <Pressable key={q.id} onPress={() => router.push(`/(app)/quizzes/${q.id}`)}>
            <Card style={{ marginBottom: spacing.sm, flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
              <View>
                <Text style={typography.bodyBold}>{q.title}</Text>
                <Text style={[typography.caption, { color: colors.textMuted, marginTop: 2 }]}>{q.total} questions</Text>
              </View>
              {q.alreadySubmitted ? (
                <Badge label={`Score: ${q.score}/${q.total}`} tone="success" />
              ) : q.hasStarted ? (
                <Badge label="In progress" tone="warning" />
              ) : (
                <Badge label="Not started" tone="neutral" />
              )}
            </Card>
          </Pressable>
        ))
      )}
    </Screen>
  );
}

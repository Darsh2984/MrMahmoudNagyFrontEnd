function SubmittedPanel({
  submission,
  gradeOutOf,
  canModify,
  uploading,
  deletingFileId,
  openingSubmissionFileId,
  openingCorrectedFile,
  onAddFiles,
  onDeleteFile,
  onOpenSubmissionFile,
  onOpenLegacySubmission,
  onOpenCorrected,
}) {
  const hasGrade =
    submission.grade != null;

  const files = Array.isArray(
    submission.files,
  )
    ? submission.files
    : [];

  return (
    <View>
      <NoticeBox
        type="success"
        title="Submission received"
        message={
          submission.submittedAt
            ? `Last updated on ${formatDate(
                submission.submittedAt,
              )}`
            : "Your homework was submitted successfully."
        }
      />

      {submission.wasModifiedAfterDeadline ||
      submission.lastModifiedAfterDeadline ? (
        <NoticeBox
          type="warning"
          title="Modified after deadline"
          message="One or more files were added, removed, or changed after the homework deadline."
        />
      ) : null}

      {files.length ? (
        <View style={styles.submissionFilesList}>
          <Text style={styles.sectionLabel}>
            Uploaded files
          </Text>

          {files.map(
            (file, index) => (
              <View
                key={file.id}
                style={styles.submittedFile}
              >
                <View
                  style={
                    styles.submissionFileOrder
                  }
                >
                  <Text
                    style={
                      styles.submissionFileOrderText
                    }
                  >
                    {index + 1}
                  </Text>
                </View>

                <Pressable
                  accessibilityRole="link"
                  onPress={() =>
                    onOpenSubmissionFile(
                      file,
                    )
                  }
                  style={styles.fileInfo}
                >
                  <Text
                    numberOfLines={1}
                    style={styles.fileTitle}
                  >
                    {file.originalName}
                  </Text>

                  <Text
                    style={
                      styles.fileSubtitle
                    }
                  >
                    {formatFileSize(
                      file.size,
                    )}
                    {file.uploadedAfterDeadline
                      ? " · Uploaded after deadline"
                      : ""}
                  </Text>
                </Pressable>

                <Pressable
                  accessibilityRole="link"
                  disabled={
                    openingSubmissionFileId ===
                    file.id
                  }
                  onPress={() =>
                    onOpenSubmissionFile(
                      file,
                    )
                  }
                  style={
                    styles.fileActionButton
                  }
                >
                  {openingSubmissionFileId ===
                  file.id ? (
                    <ActivityIndicator
                      size="small"
                      color={colors.primary}
                    />
                  ) : (
                    <Ionicons
                      name="open-outline"
                      size={19}
                      color={colors.primary}
                    />
                  )}
                </Pressable>

                {canModify ? (
                  <Pressable
                    accessibilityRole="button"
                    disabled={
                      Boolean(
                        deletingFileId,
                      )
                    }
                    onPress={() =>
                      onDeleteFile(
                        file.id,
                      )
                    }
                    style={
                      styles.deleteFileButton
                    }
                  >
                    {deletingFileId ===
                    file.id ? (
                      <ActivityIndicator
                        size="small"
                        color={colors.danger}
                      />
                    ) : (
                      <Ionicons
                        name="trash-outline"
                        size={19}
                        color={colors.danger}
                      />
                    )}
                  </Pressable>
                ) : null}
              </View>
            ),
          )}
        </View>
      ) : submission.fileUrl ? (
        <Pressable
          accessibilityRole="link"
          disabled={
            openingSubmissionFileId ===
            "legacy"
          }
          onPress={
            onOpenLegacySubmission
          }
          style={styles.submittedFile}
        >
          <View style={styles.fileIcon}>
            <Ionicons
              name="document-text-outline"
              size={22}
              color={colors.primary}
            />
          </View>

          <View style={styles.fileInfo}>
            <Text style={styles.fileTitle}>
              Submitted homework
            </Text>

            <Text style={styles.fileSubtitle}>
              Legacy single-file submission
            </Text>
          </View>

          {openingSubmissionFileId ===
          "legacy" ? (
            <ActivityIndicator
              size="small"
              color={colors.primary}
            />
          ) : (
            <Ionicons
              name="open-outline"
              size={19}
              color={colors.primary}
            />
          )}
        </Pressable>
      ) : null}

      {canModify ? (
        <View style={styles.modifySubmissionBox}>
          <Text
            style={
              styles.modifySubmissionTitle
            }
          >
            Update your submission
          </Text>

          <Text
            style={
              styles.modifySubmissionText
            }
          >
            You may add more files or remove
            uploaded files while this homework
            remains ungraded and submission
            modifications are allowed.
          </Text>

          <Button
            title={
              uploading
                ? "Uploading..."
                : "Add more files"
            }
            variant="secondary"
            loading={uploading}
            disabled={
              uploading ||
              Boolean(deletingFileId)
            }
            onPress={onAddFiles}
            style={styles.submitButton}
          />
        </View>
      ) : !hasGrade ? (
        <NoticeBox
          type="warning"
          title="Submission locked"
          message={
            submission.modificationBlockedReason ||
            "This submission can no longer be modified."
          }
        />
      ) : null}

      <View style={styles.gradeBox}>
        <Text style={styles.gradeLabel}>
          Grade
        </Text>

        {hasGrade ? (
          <>
            <View style={styles.gradeValueRow}>
              <Text style={styles.gradeValue}>
                {submission.grade}
              </Text>

              <Text
                style={styles.gradeMaximum}
              >
                / {gradeOutOf}
              </Text>
            </View>

            <Text style={styles.gradeStatus}>
              Grading completed
            </Text>
          </>
        ) : (
          <>
            <Text
              style={styles.pendingGrade}
            >
              Not graded yet
            </Text>

            <Text style={styles.gradeStatus}>
              Your teacher or assistant will
              review your submission.
            </Text>
          </>
        )}
      </View>

      {submission.comments ? (
        <View style={styles.feedbackBox}>
          <Text style={styles.feedbackLabel}>
            Grader feedback
          </Text>

          <Text style={styles.feedbackText}>
            {submission.comments}
          </Text>
        </View>
      ) : null}

      {submission.correctedFileUrl ? (
        <Pressable
          accessibilityRole="link"
          disabled={
            openingCorrectedFile
          }
          onPress={onOpenCorrected}
          style={styles.correctedFile}
        >
          <View
            style={
              styles.correctedFileIcon
            }
          >
            <Ionicons
              name="checkmark-done-outline"
              size={21}
              color={colors.secondary}
            />
          </View>

          <View style={styles.fileInfo}>
            <Text style={styles.fileTitle}>
              Corrected homework
            </Text>

            <Text style={styles.fileSubtitle}>
              Open the corrected file returned
              by the grader
            </Text>
          </View>

          {openingCorrectedFile ? (
            <ActivityIndicator
              size="small"
              color={colors.primary}
            />
          ) : (
            <Ionicons
              name="open-outline"
              size={19}
              color={colors.primary}
            />
          )}
        </Pressable>
      ) : null}
    </View>
  );
}
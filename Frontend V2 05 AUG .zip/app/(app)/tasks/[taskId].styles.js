import {
  Platform,
  StyleSheet,
} from "react-native";

import {
  colors,
  spacing,
  radius,
  typography,
} from "../../../src/theme";

export const styles = StyleSheet.create({
  page: {
    width: "100%",
    maxWidth: 1320,
    alignSelf: "center",
    paddingBottom: spacing.xl,
  },

  fullPageLoading: {
    alignItems: "center",
    justifyContent: "center",
    gap: spacing.sm,
  },

  loadingText: {
    ...typography.body,
    color: colors.textMuted,
  },

  backButton: {
    alignSelf: "flex-start",
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.xs,
    paddingVertical: spacing.sm,
    marginBottom: spacing.sm,
  },

  backButtonText: {
    fontSize: 13,
    fontWeight: "700",
    color: colors.primary,
  },

  alert: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
    padding: spacing.md,
    marginBottom: spacing.md,
    borderWidth: 1,
    borderRadius: radius.lg,
  },

  errorAlert: {
    borderColor: `${colors.danger}55`,
    backgroundColor: `${colors.danger}12`,
  },

  successAlert: {
    borderColor: colors.secondary,
    backgroundColor: `${colors.secondary}20`,
  },

  errorText: {
    flex: 1,
    ...typography.body,
    color: colors.danger,
  },

  successText: {
    flex: 1,
    ...typography.body,
    color: colors.textPrimary,
  },

  alertClose: {
    padding: 4,
  },

  heroCard: {
    marginBottom: spacing.lg,
  },

  heroContent: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: spacing.lg,
  },

  heroContentSmall: {
    flexDirection: "column",
  },

  heroIcon: {
    width: 58,
    height: 58,
    borderRadius: radius.lg,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: `${colors.secondary}25`,
  },

  heroCopy: {
    flex: 1,
    minWidth: 0,
  },

  eyebrow: {
    fontSize: 11,
    fontWeight: "800",
    letterSpacing: 1.1,
    color: colors.primary,
    marginBottom: spacing.xs,
  },

  pageTitle: {
    ...typography.h1,
    color: colors.textPrimary,
    marginBottom: spacing.sm,
  },

  pageDescription: {
    ...typography.body,
    color: colors.textMuted,
    lineHeight: 23,
    marginBottom: spacing.md,
  },

  heroBadges: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: spacing.xs,
  },

  taskGroupsSection: {
    marginTop: spacing.md,
  },

  taskGroupsLabel: {
    marginBottom: spacing.xs,
    fontSize: 11,
    fontWeight: "800",
    letterSpacing: 0.7,
    color: colors.textMuted,
    textTransform: "uppercase",
  },

  taskGroupsList: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: spacing.xs,
  },

  taskGroupBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    paddingVertical: 5,
    paddingHorizontal: spacing.sm,
    borderWidth: 1,
    borderColor: `${colors.secondary}45`,
    borderRadius: radius.pill,
    backgroundColor: `${colors.secondary}18`,
  },

  taskGroupBadgeText: {
    fontSize: 11,
    fontWeight: "700",
    color: colors.primary,
  },

  taskGroupsUnavailable: {
    fontSize: 12,
    color: colors.textMuted,
  },

  statsGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: spacing.md,
    marginBottom: spacing.lg,
  },

  statCard: {
    flex: 1,
    minWidth: 180,
  },

  statIcon: {
    width: 42,
    height: 42,
    borderRadius: radius.lg,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: spacing.md,
    backgroundColor: `${colors.secondary}25`,
  },

  statValue: {
    fontSize: 26,
    fontWeight: "800",
    color: colors.textPrimary,
  },

  statLabel: {
    marginTop: 3,
    fontSize: 12,
    color: colors.textMuted,
  },

  contentLayout: {
    gap: spacing.lg,
  },

  contentLayoutDesktop: {
    flexDirection: "row",
    alignItems: "flex-start",
  },

  mainColumn: {
    flex: 1,
    minWidth: 0,
  },

  sideColumn: {
    width: "100%",
    gap: spacing.md,
  },

  sideColumnDesktop: {
    width: 320,
  },

  sectionHeader: {
    flexDirection: "row",
    flexWrap: "wrap",
    alignItems: "flex-start",
    justifyContent: "space-between",
    gap: spacing.sm,
    marginBottom: spacing.md,
  },

  sectionTitle: {
    fontSize: 19,
    fontWeight: "800",
    color: colors.textPrimary,
  },

  sectionSubtitle: {
    marginTop: 4,
    fontSize: 12,
    lineHeight: 18,
    color: colors.textMuted,
  },

  sectionCount: {
    fontSize: 12,
    fontWeight: "700",
    color: colors.primary,
  },

  submissionList: {
    gap: spacing.md,
  },

  submissionCard: {
    gap: spacing.md,
  },

  submissionHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: spacing.md,
  },

  submissionHeaderSmall: {
    alignItems: "flex-start",
    flexDirection: "column",
  },

  studentIdentity: {
    flex: 1,
    minWidth: 0,
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
  },

  studentAvatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.primary,
  },

  studentAvatarText: {
    fontSize: 16,
    fontWeight: "800",
    color: colors.white,
  },

  studentInfo: {
    flex: 1,
    minWidth: 0,
  },

  studentName: {
    fontSize: 15,
    fontWeight: "800",
    color: colors.textPrimary,
  },

  studentMeta: {
    marginTop: 3,
    fontSize: 11,
    color: colors.textMuted,
  },

  submissionDetails: {
    gap: spacing.sm,
  },

  detailRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.xs,
  },

  detailText: {
    fontSize: 12,
    color: colors.textMuted,
  },

  fileButton: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.lg,
    backgroundColor: colors.background,
  },

  fileButtonIcon: {
    width: 40,
    height: 40,
    borderRadius: radius.lg,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.white,
  },

  fileButtonText: {
    flex: 1,
  },

  fileButtonTitle: {
    fontSize: 13,
    fontWeight: "700",
    color: colors.textPrimary,
  },

  fileButtonSubtitle: {
    marginTop: 3,
    fontSize: 11,
    color: colors.textMuted,
  },

  noFileBox: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.xs,
    padding: spacing.md,
    borderRadius: radius.lg,
    backgroundColor: colors.background,
  },

  noFileText: {
    fontSize: 12,
    color: colors.textMuted,
  },

  gradingPanel: {
    paddingTop: spacing.md,
    borderTopWidth: 1,
    borderTopColor: colors.background,
  },

  gradingHeading: {
    marginBottom: spacing.sm,
  },

  gradingTitle: {
    fontSize: 15,
    fontWeight: "800",
    color: colors.textPrimary,
  },

  gradingSubtitle: {
    marginTop: 3,
    fontSize: 11,
    lineHeight: 17,
    color: colors.textMuted,
  },

  gradeRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
  },

  gradeRowSmall: {
    alignItems: "stretch",
    flexDirection: "column",
  },

  gradeInputWrapper: {
    flex: 1,
    minHeight: 48,
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    backgroundColor: colors.white,
  },

  gradeInput: {
    flex: 1,
    minHeight: 46,
    paddingHorizontal: spacing.md,
    color: colors.textPrimary,
    fontSize: 14,
  },

  gradeSuffix: {
    paddingHorizontal: spacing.md,
    borderLeftWidth: 1,
    borderLeftColor: colors.border,
  },

  gradeSuffixText: {
    fontSize: 13,
    fontWeight: "700",
    color: colors.textMuted,
  },

  dividerRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
    marginVertical: spacing.md,
  },

  divider: {
    flex: 1,
    height: 1,
    backgroundColor: colors.border,
  },

  dividerText: {
    fontSize: 10,
    fontWeight: "800",
    color: colors.textMuted,
  },

  delegationPanel: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
    padding: spacing.md,
    borderRadius: radius.lg,
    backgroundColor: `${colors.warning}12`,
  },

  delegationIcon: {
    width: 40,
    height: 40,
    borderRadius: radius.lg,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.white,
  },

  delegationText: {
    flex: 1,
  },

  delegationTitle: {
    fontSize: 13,
    fontWeight: "800",
    color: colors.textPrimary,
  },

  delegationSubtitle: {
    marginTop: 3,
    fontSize: 11,
    lineHeight: 17,
    color: colors.textMuted,
  },

  gradedPanel: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
    padding: spacing.md,
    borderRadius: radius.lg,
    backgroundColor: `${colors.secondary}18`,
  },

  gradedIcon: {
    width: 40,
    height: 40,
    borderRadius: radius.lg,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.white,
  },

  gradedText: {
    flex: 1,
  },

  gradedTitle: {
    fontSize: 13,
    fontWeight: "800",
    color: colors.textPrimary,
  },

  gradedSubtitle: {
    marginTop: 3,
    fontSize: 11,
    color: colors.textMuted,
  },

  emptyCard: {
    minHeight: 280,
    alignItems: "center",
    justifyContent: "center",
    padding: spacing.xl,
  },

  emptyIcon: {
    width: 70,
    height: 70,
    borderRadius: 35,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: spacing.md,
    backgroundColor: `${colors.secondary}22`,
  },

  emptyTitle: {
    fontSize: 18,
    fontWeight: "800",
    color: colors.textPrimary,
    textAlign: "center",
    marginBottom: spacing.xs,
  },

  emptyDescription: {
    ...typography.body,
    maxWidth: 430,
    color: colors.textMuted,
    lineHeight: 21,
    textAlign: "center",
  },

  progressCard: {
    gap: spacing.sm,
  },

  sideCardIcon: {
    width: 42,
    height: 42,
    borderRadius: radius.lg,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: `${colors.secondary}25`,
  },

  sideCardTitle: {
    fontSize: 15,
    fontWeight: "800",
    color: colors.textPrimary,
  },

  progressValue: {
    fontSize: 31,
    fontWeight: "800",
    color: colors.primary,
  },

  progressTrack: {
    height: 8,
    overflow: "hidden",
    borderRadius: 4,
    backgroundColor: colors.border,
  },

  progressFill: {
    height: "100%",
    borderRadius: 4,
    backgroundColor: colors.secondary,
  },

  progressText: {
    fontSize: 11,
    color: colors.textMuted,
  },

  infoCard: {
    backgroundColor: `${colors.secondary}16`,
  },

  infoText: {
    ...typography.caption,
    color: colors.textMuted,
    lineHeight: 19,
    marginTop: spacing.sm,
  },

  notFoundCard: {
    minHeight: 360,
    alignItems: "center",
    justifyContent: "center",
    padding: spacing.xl,
  },

  notFoundIcon: {
    width: 72,
    height: 72,
    borderRadius: 36,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: spacing.md,
    backgroundColor: `${colors.danger}12`,
  },

  notFoundTitle: {
    fontSize: 20,
    fontWeight: "800",
    color: colors.textPrimary,
    marginBottom: spacing.sm,
  },

  notFoundText: {
    ...typography.body,
    maxWidth: 430,
    color: colors.textMuted,
    textAlign: "center",
    marginBottom: spacing.md,
  },

  modalBackdrop: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: spacing.lg,
    backgroundColor:
      "rgba(20,28,30,0.54)",
  },

  modalCard: {
    width: "100%",
    maxWidth: 620,
    maxHeight: "88%",
    padding: spacing.lg,
    borderRadius: radius.lg,
    backgroundColor: colors.white,

    ...Platform.select({
      web: {
        boxShadow:
          "0 18px 50px rgba(0,0,0,0.18)",
      },

      default: {
        elevation: 8,
      },
    }),
  },

  modalHeader: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: spacing.sm,
    marginBottom: spacing.lg,
  },

  modalIcon: {
    width: 44,
    height: 44,
    borderRadius: radius.lg,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: `${colors.secondary}25`,
  },

  modalHeadingCopy: {
    flex: 1,
  },

  modalTitle: {
    fontSize: 20,
    fontWeight: "800",
    color: colors.textPrimary,
    marginBottom: 4,
  },

  mutedText: {
    ...typography.caption,
    color: colors.textMuted,
    lineHeight: 18,
  },

  modalClose: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.background,
  },

  modalError: {
    marginBottom: spacing.md,
  },

  searchBox: {
    minHeight: 48,
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
    paddingHorizontal: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    marginBottom: spacing.md,
    backgroundColor: colors.white,
  },

  searchInput: {
    flex: 1,
    minHeight: 46,
    color: colors.textPrimary,
    fontSize: 14,
  },

  modalState: {
    minHeight: 190,
    alignItems: "center",
    justifyContent: "center",
    gap: spacing.sm,
  },

  modalEmptyTitle: {
    fontSize: 16,
    fontWeight: "800",
    color: colors.textPrimary,
  },

  modalEmptyText: {
    maxWidth: 390,
    textAlign: "center",
  },

  assistantList: {
    maxHeight: 380,
  },

  assistantListContent: {
    paddingBottom: spacing.xs,
  },

  assistantRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
    paddingVertical: spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: colors.background,
  },

  assistantAvatar: {
    width: 42,
    height: 42,
    borderRadius: 21,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.primary,
  },

  assistantAvatarText: {
    fontSize: 15,
    fontWeight: "800",
    color: colors.white,
  },

  assistantInfo: {
    flex: 1,
    minWidth: 0,
  },

  assistantName: {
    fontSize: 14,
    fontWeight: "700",
    color: colors.textPrimary,
  },

  assistantRole: {
    marginTop: 2,
    fontSize: 11,
    color: colors.textMuted,
  },

  assistantGroups: {
    marginTop: 3,
    fontSize: 10,
    lineHeight: 15,
    color: colors.textMuted,
  },

  modalActions: {
    flexDirection: "row",
    justifyContent: "flex-end",
    marginTop: spacing.lg,
    paddingTop: spacing.md,
    borderTopWidth: 1,
    borderTopColor: colors.background,
  },

  disabled: {
    opacity: 0.45,
  },

  pressed: {
    opacity: 0.76,
  },
});
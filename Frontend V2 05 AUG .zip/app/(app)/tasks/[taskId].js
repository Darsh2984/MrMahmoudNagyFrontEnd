import React, {
  useCallback,
  useEffect,
  useMemo,
  useState,
} from "react";

import {
  ActivityIndicator,
  Linking,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  useWindowDimensions,
  View,
} from "react-native";

import { Ionicons } from "@expo/vector-icons";
import {
  useLocalSearchParams,
  useRouter,
} from "expo-router";

import { Screen } from "../../../src/components/layout/Screen";
import { Card } from "../../../src/components/ui/Card";
import { Button } from "../../../src/components/ui/Button";
import { Badge } from "../../../src/components/ui/Badge";

import { useAuth } from "../../../src/contexts/AuthContext";
import api from "../../../src/lib/api";
import { formatDate } from "../../../src/utils/formatDate";

import {
  colors,
  spacing,
} from "../../../src/theme";

import { styles } from "./[taskId].styles";

function getErrorMessage(error, fallback) {
  return (
    error?.response?.data?.msg ||
    error?.response?.data?.message ||
    fallback
  );
}

function getInitial(name) {
  return (
    name?.trim()?.charAt(0)?.toUpperCase() ||
    "S"
  );
}

function normalizeTaskGroups(task) {
  if (!Array.isArray(task?.groups)) {
    return [];
  }

  return task.groups
    .map((taskGroup) => taskGroup?.group)
    .filter(Boolean);
}

export default function TeacherTaskDetail() {
  const router = useRouter();
  const params = useLocalSearchParams();
  const { width } = useWindowDimensions();
  const { user } = useAuth();

  const taskId = Array.isArray(params.taskId)
    ? params.taskId[0]
    : params.taskId;

  const isDesktop = width >= 980;
  const isSmallScreen = width < 640;

  const isAdminLevel =
    user?.role === "TEACHER" ||
    Boolean(user?.isHeadAssistant);

  const isRegularAssistant =
    user?.role === "ASSISTANT" &&
    !user?.isHeadAssistant;

  const [task, setTask] = useState(null);

  const [gradeInputs, setGradeInputs] =
    useState({});

  const [loading, setLoading] =
    useState(true);

  const [
    gradingSubmissionId,
    setGradingSubmissionId,
  ] = useState(null);

  const [
    delegatingSubmissionId,
    setDelegatingSubmissionId,
  ] = useState(null);

  const [
    selectedSubmission,
    setSelectedSubmission,
  ] = useState(null);

  const [
    delegateModalVisible,
    setDelegateModalVisible,
  ] = useState(false);

  const [assistantSearch, setAssistantSearch] =
    useState("");

  const [delegateError, setDelegateError] =
    useState("");

  const [error, setError] = useState("");
  const [success, setSuccess] =
    useState("");

  const submissions = useMemo(() => {
    return Array.isArray(task?.submissions)
      ? task.submissions
      : [];
  }, [task]);

  const taskGroups = useMemo(() => {
    return normalizeTaskGroups(task);
  }, [task]);

  const eligibleAssistants = useMemo(() => {
    const uniqueAssistants = new Map();

    for (const taskGroup of task?.groups || []) {
      const assignments =
        taskGroup?.group
          ?.assistantAssignments || [];

      for (const assignment of assignments) {
        const assistant =
          assignment?.assistant;

        if (!assistant?.id) {
          continue;
        }

        const canGradeHomework =
          assistant.isHeadAssistant === true ||
          assistant.permissions
            ?.canGradeHomework === true;

        if (!canGradeHomework) {
          continue;
        }

        uniqueAssistants.set(
          String(assistant.id),
          assistant
        );
      }
    }

    return Array.from(
      uniqueAssistants.values()
    );
  }, [task]);

  const filteredAssistants =
    useMemo(() => {
      const query = assistantSearch
        .trim()
        .toLowerCase();

      if (!query) {
        return eligibleAssistants;
      }

      return eligibleAssistants.filter(
        (assistant) =>
          assistant.name
            ?.toLowerCase()
            .includes(query) ||
          assistant.email
            ?.toLowerCase()
            .includes(query)
      );
    }, [
      assistantSearch,
      eligibleAssistants,
    ]);

  const summary = useMemo(() => {
    return submissions.reduce(
      (result, submission) => {
        if (submission.grade != null) {
          result.graded += 1;
        } else if (submission.delegation) {
          result.delegated += 1;
        } else {
          result.pending += 1;
        }

        return result;
      },
      {
        total: submissions.length,
        graded: 0,
        delegated: 0,
        pending: 0,
      }
    );
  }, [submissions]);

  const progressPercentage = useMemo(() => {
    if (!summary.total) {
      return 0;
    }

    return Math.round(
      (summary.graded / summary.total) * 100
    );
  }, [summary]);

  const clearMessages = useCallback(() => {
    setError("");
    setSuccess("");
  }, []);

  const loadTask = useCallback(async () => {
    if (!taskId) {
      setError("Task ID is missing.");
      setLoading(false);
      return;
    }

    setLoading(true);
    setError("");

    try {
      const response = await api.get(
        `/tasks/${taskId}`
      );

      setTask(response.data);
    } catch (requestError) {
      setError(
        getErrorMessage(
          requestError,
          "Couldn't load task details."
        )
      );
    } finally {
      setLoading(false);
    }
  }, [taskId]);

  useEffect(() => {
    loadTask();
  }, [loadTask]);

  async function openExternalFile(url) {
    if (!url) {
      return;
    }

    clearMessages();

    try {
      const supported =
        await Linking.canOpenURL(url);

      if (!supported) {
        setError(
          "This file link cannot be opened."
        );
        return;
      }

      await Linking.openURL(url);
    } catch {
      setError("Couldn't open the file.");
    }
  }

  function validateGrade(submissionId) {
    const rawValue =
      gradeInputs[submissionId];

    const grade = Number(rawValue);

    if (
      rawValue === undefined ||
      rawValue === "" ||
      !Number.isFinite(grade)
    ) {
      return {
        valid: false,
        message:
          "Enter a valid numeric grade.",
      };
    }

    if (grade < 0) {
      return {
        valid: false,
        message:
          "Grade cannot be negative.",
      };
    }

    if (
      task?.gradeOutOf != null &&
      grade > Number(task.gradeOutOf)
    ) {
      return {
        valid: false,
        message: `Grade cannot exceed ${task.gradeOutOf}.`,
      };
    }

    return {
      valid: true,
      grade,
    };
  }

  async function gradeDirectly(
    submissionId
  ) {
    clearMessages();

    const validation =
      validateGrade(submissionId);

    if (!validation.valid) {
      setError(validation.message);
      return;
    }

    setGradingSubmissionId(submissionId);

    try {
      await api.patch(
        `/submissions/${submissionId}/grade`,
        {
          grade: validation.grade,
        }
      );

      setGradeInputs((current) => {
        const updated = { ...current };
        delete updated[submissionId];
        return updated;
      });

      setSuccess(
        "Grade saved successfully."
      );

      await loadTask();
    } catch (requestError) {
      setError(
        getErrorMessage(
          requestError,
          "Couldn't save the grade."
        )
      );
    } finally {
      setGradingSubmissionId(null);
    }
  }

  function openDelegateModal(submission) {
    clearMessages();
    setDelegateError("");
    setSelectedSubmission(submission);
    setAssistantSearch("");
    setDelegateModalVisible(true);
  }

  function closeDelegateModal() {
    if (delegatingSubmissionId) {
      return;
    }

    setDelegateModalVisible(false);
    setSelectedSubmission(null);
    setAssistantSearch("");
    setDelegateError("");
  }

  async function delegate(assistantId) {
    if (!selectedSubmission) {
      return;
    }

    setDelegateError("");

    setDelegatingSubmissionId(
      selectedSubmission.id
    );

    try {
      await api.post("/delegations", {
        submissionId:
          selectedSubmission.id,
        assistantId,
      });

      setSuccess(
        "Submission delegated successfully."
      );

      setDelegateError("");
      setDelegateModalVisible(false);
      setSelectedSubmission(null);
      setAssistantSearch("");

      await loadTask();
    } catch (requestError) {
      setDelegateError(
        getErrorMessage(
          requestError,
          "Couldn't delegate the submission."
        )
      );
    } finally {
      setDelegatingSubmissionId(null);
    }
  }

  function getAssistantGroupNames(
    assistantId
  ) {
    return (task?.groups || [])
      .filter((taskGroup) =>
        taskGroup?.group
          ?.assistantAssignments?.some(
            (assignment) =>
              String(
                assignment?.assistant?.id
              ) === String(assistantId)
          )
      )
      .map(
        (taskGroup) =>
          taskGroup?.group?.name
      )
      .filter(Boolean);
  }

  function renderGradeForm(
    submission,
    {
      title = "Grade submission",
      subtitle,
    } = {}
  ) {
    return (
      <View style={styles.gradingPanel}>
        <View style={styles.gradingHeading}>
          <Text style={styles.gradingTitle}>
            {title}
          </Text>

          <Text
            style={styles.gradingSubtitle}
          >
            {subtitle ||
              `Enter a grade out of ${
                task?.gradeOutOf ??
                "the task total"
              }.`}
          </Text>
        </View>

        <View
          style={[
            styles.gradeRow,
            isSmallScreen &&
              styles.gradeRowSmall,
          ]}
        >
          <View
            style={styles.gradeInputWrapper}
          >
            <TextInput
              value={
                gradeInputs[submission.id] ||
                ""
              }
              onChangeText={(value) =>
                setGradeInputs((current) => ({
                  ...current,
                  [submission.id]: value,
                }))
              }
              placeholder={`Grade out of ${
                task?.gradeOutOf ?? ""
              }`}
              keyboardType="numeric"
              placeholderTextColor={
                colors.textMuted
              }
              style={styles.gradeInput}
            />

            <View style={styles.gradeSuffix}>
              <Text
                style={
                  styles.gradeSuffixText
                }
              >
                / {task?.gradeOutOf ?? "-"}
              </Text>
            </View>
          </View>

          <Button
            title="Save grade"
            variant="secondary"
            onPress={() =>
              gradeDirectly(submission.id)
            }
            loading={
              gradingSubmissionId ===
              submission.id
            }
            disabled={Boolean(
              gradingSubmissionId
            )}
          />
        </View>
      </View>
    );
  }

  function renderSubmissionCard(
    submission
  ) {
    const graded =
      submission.grade != null;

    const delegated = Boolean(
      submission.delegation
    );

    const pending =
      !graded && !delegated;

    const delegatedAssistantId =
      submission.delegation?.assistant?.id ||
      submission.delegation
        ?.assistantId;

    const delegatedToCurrentUser =
      delegated &&
      String(delegatedAssistantId) ===
        String(user?.id);

    return (
      <Card
        key={submission.id}
        style={styles.submissionCard}
      >
        <View
          style={[
            styles.submissionHeader,
            isSmallScreen &&
              styles.submissionHeaderSmall,
          ]}
        >
          <View
            style={styles.studentIdentity}
          >
            <View
              style={styles.studentAvatar}
            >
              <Text
                style={
                  styles.studentAvatarText
                }
              >
                {getInitial(
                  submission.student?.name
                )}
              </Text>
            </View>

            <View style={styles.studentInfo}>
              <Text
                numberOfLines={1}
                style={styles.studentName}
              >
                {submission.student?.name ||
                  "Unknown student"}
              </Text>

              <Text
                style={styles.studentMeta}
              >
                Homework submission
              </Text>
            </View>
          </View>

          {graded ? (
            <Badge
              label={`Graded: ${submission.grade}/${task?.gradeOutOf}`}
              tone="success"
            />
          ) : delegatedToCurrentUser ? (
            <Badge
              label="Assigned to you"
              tone="warning"
            />
          ) : delegated ? (
            <Badge
              label={`Delegated to ${
                submission.delegation
                  ?.assistant?.name ||
                "assistant"
              }`}
              tone="warning"
            />
          ) : (
            <Badge
              label="Ungraded"
              tone="neutral"
            />
          )}
        </View>

        <View
          style={styles.submissionDetails}
        >
          <View style={styles.detailRow}>
            <Ionicons
              name="calendar-outline"
              size={16}
              color={colors.textMuted}
            />

            <Text style={styles.detailText}>
              Submitted{" "}
              {submission.createdAt
                ? formatDate(
                    submission.createdAt
                  )
                : "date unavailable"}
            </Text>
          </View>

          {submission.fileUrl ? (
            <Pressable
              onPress={() =>
                openExternalFile(
                  submission.fileUrl
                )
              }
              style={({ pressed }) => [
                styles.fileButton,
                pressed && styles.pressed,
              ]}
            >
              <View
                style={
                  styles.fileButtonIcon
                }
              >
                <Ionicons
                  name="document-text-outline"
                  size={19}
                  color={colors.primary}
                />
              </View>

              <View
                style={
                  styles.fileButtonText
                }
              >
                <Text
                  style={
                    styles.fileButtonTitle
                  }
                >
                  View submission file
                </Text>

                <Text
                  style={
                    styles.fileButtonSubtitle
                  }
                >
                  Open the student's uploaded
                  answer
                </Text>
              </View>

              <Ionicons
                name="open-outline"
                size={18}
                color={colors.primary}
              />
            </Pressable>
          ) : (
            <View style={styles.noFileBox}>
              <Ionicons
                name="document-outline"
                size={18}
                color={colors.textMuted}
              />

              <Text
                style={styles.noFileText}
              >
                No submission file attached
              </Text>
            </View>
          )}
        </View>

        {pending && isAdminLevel ? (
          <>
            {renderGradeForm(submission)}

            <View
              style={styles.dividerRow}
            >
              <View style={styles.divider} />

              <Text
                style={styles.dividerText}
              >
                OR
              </Text>

              <View style={styles.divider} />
            </View>

            <Button
              title="Delegate to assistant"
              variant="outline"
              onPress={() =>
                openDelegateModal(submission)
              }
            />
          </>
        ) : null}

        {delegated && !graded ? (
          <View
            style={styles.delegationPanel}
          >
            <View
              style={styles.delegationIcon}
            >
              <Ionicons
                name={
                  delegatedToCurrentUser
                    ? "person-circle-outline"
                    : "person-outline"
                }
                size={20}
                color={colors.warning}
              />
            </View>

            <View
              style={styles.delegationText}
            >
              <Text
                style={
                  styles.delegationTitle
                }
              >
                {delegatedToCurrentUser
                  ? "Assigned to you for grading"
                  : "Waiting for assistant grading"}
              </Text>

              <Text
                style={
                  styles.delegationSubtitle
                }
              >
                {delegatedToCurrentUser
                  ? `This submission was delegated to you. Grade it out of ${
                      task?.gradeOutOf ??
                      "-"
                    }.`
                  : `Assigned to ${
                      submission.delegation
                        ?.assistant?.name ||
                      "an assistant"
                    }.`}
              </Text>
            </View>
          </View>
        ) : null}

        {delegatedToCurrentUser &&
        !graded ? (
          renderGradeForm(submission, {
            title:
              "Grade delegated submission",
            subtitle: `Enter the final grade out of ${
              task?.gradeOutOf ??
              "the task total"
            }.`,
          })
        ) : null}

        {graded ? (
          <View style={styles.gradedPanel}>
            <View style={styles.gradedIcon}>
              <Ionicons
                name="checkmark-circle-outline"
                size={21}
                color={colors.primary}
              />
            </View>

            <View style={styles.gradedText}>
              <Text
                style={styles.gradedTitle}
              >
                Grading completed
              </Text>

              <Text
                style={
                  styles.gradedSubtitle
                }
              >
                Final grade:{" "}
                {submission.grade}/
                {task?.gradeOutOf}
              </Text>
            </View>
          </View>
        ) : null}
      </Card>
    );
  }

  if (loading) {
    return (
      <Screen
        scroll={false}
        style={styles.fullPageLoading}
      >
        <ActivityIndicator
          color={colors.primary}
          size="large"
        />

        <Text style={styles.loadingText}>
          Loading task details…
        </Text>
      </Screen>
    );
  }

  if (!task) {
    return (
      <Screen>
        <Card style={styles.notFoundCard}>
          <View
            style={styles.notFoundIcon}
          >
            <Ionicons
              name="alert-circle-outline"
              size={36}
              color={colors.danger}
            />
          </View>

          <Text
            style={styles.notFoundTitle}
          >
            Task unavailable
          </Text>

          <Text style={styles.notFoundText}>
            {error ||
              "The task could not be loaded or may no longer exist."}
          </Text>

          <Button
            title="Go back"
            variant="outline"
            onPress={() => router.back()}
          />
        </Card>
      </Screen>
    );
  }

  return (
    <Screen>
      <View style={styles.page}>
        <Pressable
          onPress={() => router.back()}
          style={({ pressed }) => [
            styles.backButton,
            pressed && styles.pressed,
          ]}
        >
          <Ionicons
            name="arrow-back"
            size={18}
            color={colors.primary}
          />

          <Text
            style={styles.backButtonText}
          >
            Back to tasks
          </Text>
        </Pressable>

        {error ? (
          <View
            style={[
              styles.alert,
              styles.errorAlert,
            ]}
          >
            <Ionicons
              name="alert-circle-outline"
              size={20}
              color={colors.danger}
            />

            <Text style={styles.errorText}>
              {error}
            </Text>

            <Pressable
              accessibilityLabel="Dismiss error"
              onPress={() => setError("")}
              style={styles.alertClose}
            >
              <Ionicons
                name="close"
                size={18}
                color={colors.danger}
              />
            </Pressable>
          </View>
        ) : null}

        {success ? (
          <View
            style={[
              styles.alert,
              styles.successAlert,
            ]}
          >
            <Ionicons
              name="checkmark-circle-outline"
              size={20}
              color={colors.primary}
            />

            <Text style={styles.successText}>
              {success}
            </Text>

            <Pressable
              accessibilityLabel="Dismiss success message"
              onPress={() => setSuccess("")}
              style={styles.alertClose}
            >
              <Ionicons
                name="close"
                size={18}
                color={colors.primary}
              />
            </Pressable>
          </View>
        ) : null}

        <Card style={styles.heroCard}>
          <View
            style={[
              styles.heroContent,
              isSmallScreen &&
                styles.heroContentSmall,
            ]}
          >
            <View style={styles.heroIcon}>
              <Ionicons
                name="clipboard-outline"
                size={29}
                color={colors.primary}
              />
            </View>

            <View style={styles.heroCopy}>
              <Text style={styles.eyebrow}>
                HOMEWORK TASK
              </Text>

              <Text style={styles.pageTitle}>
                {task.title}
              </Text>

              <Text
                style={styles.pageDescription}
              >
                {task.description ||
                  "No additional instructions were provided."}
              </Text>

              <View
                style={styles.heroBadges}
              >
                <Badge
                  label={`Due ${formatDate(
                    task.deadline
                  )}`}
                  tone="neutral"
                />

                <Badge
                  label={
                    task.allowLateSubmission
                      ? "Late submissions allowed"
                      : "No late submissions"
                  }
                  tone={
                    task.allowLateSubmission
                      ? "success"
                      : "danger"
                  }
                />

                <Badge
                  label={`Grade out of ${task.gradeOutOf}`}
                  tone="info"
                />
              </View>

              <View
                style={styles.taskGroupsSection}
              >
                <Text
                  style={
                    styles.taskGroupsLabel
                  }
                >
                  Assigned groups
                </Text>

                <View
                  style={
                    styles.taskGroupsList
                  }
                >
                  {taskGroups.length ? (
                    taskGroups.map((group) => (
                      <View
                        key={group.id}
                        style={
                          styles.taskGroupBadge
                        }
                      >
                        <Ionicons
                          name="people-outline"
                          size={13}
                          color={colors.primary}
                        />

                        <Text
                          style={
                            styles.taskGroupBadgeText
                          }
                        >
                          {group.name}
                        </Text>
                      </View>
                    ))
                  ) : (
                    <Text
                      style={
                        styles.taskGroupsUnavailable
                      }
                    >
                      Group information unavailable
                    </Text>
                  )}
                </View>
              </View>
            </View>

            {task.taskFileUrl ? (
              <Button
                title="Open homework PDF"
                variant="outline"
                onPress={() =>
                  openExternalFile(
                    task.taskFileUrl
                  )
                }
              />
            ) : null}
          </View>
        </Card>

        <View style={styles.statsGrid}>
          <Card style={styles.statCard}>
            <View style={styles.statIcon}>
              <Ionicons
                name="documents-outline"
                size={22}
                color={colors.primary}
              />
            </View>

            <Text style={styles.statValue}>
              {summary.total}
            </Text>

            <Text style={styles.statLabel}>
              Total submissions
            </Text>
          </Card>

          <Card style={styles.statCard}>
            <View style={styles.statIcon}>
              <Ionicons
                name="checkmark-done-outline"
                size={22}
                color={colors.primary}
              />
            </View>

            <Text style={styles.statValue}>
              {summary.graded}
            </Text>

            <Text style={styles.statLabel}>
              Graded
            </Text>
          </Card>

          <Card style={styles.statCard}>
            <View style={styles.statIcon}>
              <Ionicons
                name="person-outline"
                size={22}
                color={colors.warning}
              />
            </View>

            <Text style={styles.statValue}>
              {summary.delegated}
            </Text>

            <Text style={styles.statLabel}>
              Delegated
            </Text>
          </Card>

          <Card style={styles.statCard}>
            <View style={styles.statIcon}>
              <Ionicons
                name="time-outline"
                size={22}
                color={colors.danger}
              />
            </View>

            <Text style={styles.statValue}>
              {summary.pending}
            </Text>

            <Text style={styles.statLabel}>
              Awaiting action
            </Text>
          </Card>
        </View>

        <View
          style={[
            styles.contentLayout,
            isDesktop &&
              styles.contentLayoutDesktop,
          ]}
        >
          <View style={styles.mainColumn}>
            <View
              style={styles.sectionHeader}
            >
              <View>
                <Text
                  style={styles.sectionTitle}
                >
                  {isRegularAssistant
                    ? "My delegated submissions"
                    : "Student submissions"}
                </Text>

                <Text
                  style={
                    styles.sectionSubtitle
                  }
                >
                  {isRegularAssistant
                    ? "Review and grade submissions delegated specifically to you."
                    : "Review, grade, or delegate submitted work."}
                </Text>
              </View>

              <Text
                style={styles.sectionCount}
              >
                {submissions.length}{" "}
                {submissions.length === 1
                  ? "submission"
                  : "submissions"}
              </Text>
            </View>

            {!submissions.length ? (
              <Card style={styles.emptyCard}>
                <View
                  style={styles.emptyIcon}
                >
                  <Ionicons
                    name="document-outline"
                    size={35}
                    color={colors.primary}
                  />
                </View>

                <Text
                  style={styles.emptyTitle}
                >
                  {isRegularAssistant
                    ? "No submissions delegated to you"
                    : "No submissions yet"}
                </Text>

                <Text
                  style={
                    styles.emptyDescription
                  }
                >
                  {isRegularAssistant
                    ? "Submissions will appear here after a Teacher or Head Assistant delegates them to you."
                    : "Student work will appear here after the first submission is received."}
                </Text>
              </Card>
            ) : (
              <View
                style={
                  styles.submissionList
                }
              >
                {submissions.map(
                  renderSubmissionCard
                )}
              </View>
            )}
          </View>

          <View
            style={[
              styles.sideColumn,
              isDesktop &&
                styles.sideColumnDesktop,
            ]}
          >
            <Card style={styles.progressCard}>
              <View
                style={styles.sideCardIcon}
              >
                <Ionicons
                  name="analytics-outline"
                  size={22}
                  color={colors.primary}
                />
              </View>

              <Text
                style={styles.sideCardTitle}
              >
                Grading progress
              </Text>

              <Text
                style={styles.progressValue}
              >
                {progressPercentage}%
              </Text>

              <View
                style={styles.progressTrack}
              >
                <View
                  style={[
                    styles.progressFill,
                    {
                      width: `${progressPercentage}%`,
                    },
                  ]}
                />
              </View>

              <Text
                style={styles.progressText}
              >
                {summary.graded} of{" "}
                {summary.total} submissions graded
              </Text>
            </Card>

            <Card style={styles.infoCard}>
              <View
                style={styles.sideCardIcon}
              >
                <Ionicons
                  name="information-circle-outline"
                  size={22}
                  color={colors.primary}
                />
              </View>

              <Text
                style={styles.sideCardTitle}
              >
                Grading workflow
              </Text>

              <Text style={styles.infoText}>
                {isRegularAssistant
                  ? "Only submissions delegated directly to you are shown. Complete the grade to return the result to the student."
                  : "Grade submissions directly or delegate them to an eligible assistant assigned to the task's groups."}
              </Text>
            </Card>
          </View>
        </View>
      </View>

      <Modal
        visible={delegateModalVisible}
        transparent
        animationType="fade"
        onRequestClose={closeDelegateModal}
      >
        <View style={styles.modalBackdrop}>
          <Pressable
            style={StyleSheet.absoluteFill}
            onPress={closeDelegateModal}
          />

          <View style={styles.modalCard}>
            <View style={styles.modalHeader}>
              <View style={styles.modalIcon}>
                <Ionicons
                  name="person-add-outline"
                  size={24}
                  color={colors.primary}
                />
              </View>

              <View
                style={
                  styles.modalHeadingCopy
                }
              >
                <Text
                  style={styles.modalTitle}
                >
                  Delegate submission
                </Text>

                <Text style={styles.mutedText}>
                  Choose an eligible assistant
                  assigned to the task's groups
                  to grade{" "}
                  {selectedSubmission?.student
                    ?.name ||
                    "this student's"}{" "}
                  submission.
                </Text>
              </View>

              <Pressable
                accessibilityLabel="Close"
                disabled={Boolean(
                  delegatingSubmissionId
                )}
                onPress={closeDelegateModal}
                style={({ pressed }) => [
                  styles.modalClose,
                  delegatingSubmissionId &&
                    styles.disabled,
                  pressed &&
                    !delegatingSubmissionId &&
                    styles.pressed,
                ]}
              >
                <Ionicons
                  name="close"
                  size={22}
                  color={colors.textPrimary}
                />
              </Pressable>
            </View>

            {delegateError ? (
              <View
                style={[
                  styles.alert,
                  styles.errorAlert,
                  styles.modalError,
                ]}
              >
                <Ionicons
                  name="alert-circle-outline"
                  size={19}
                  color={colors.danger}
                />

                <Text
                  style={styles.errorText}
                >
                  {delegateError}
                </Text>

                <Pressable
                  onPress={() =>
                    setDelegateError("")
                  }
                  style={styles.alertClose}
                >
                  <Ionicons
                    name="close"
                    size={17}
                    color={colors.danger}
                  />
                </Pressable>
              </View>
            ) : null}

            <View style={styles.searchBox}>
              <Ionicons
                name="search-outline"
                size={18}
                color={colors.textMuted}
              />

              <TextInput
                value={assistantSearch}
                onChangeText={
                  setAssistantSearch
                }
                placeholder="Search eligible assistants"
                placeholderTextColor={
                  colors.textMuted
                }
                style={styles.searchInput}
              />
            </View>

            {!filteredAssistants.length ? (
              <View style={styles.modalState}>
                <Ionicons
                  name="people-outline"
                  size={38}
                  color={colors.primary}
                />

                <Text
                  style={
                    styles.modalEmptyTitle
                  }
                >
                  No eligible assistants
                </Text>

                <Text
                  style={[
                    styles.mutedText,
                    styles.modalEmptyText,
                  ]}
                >
                  {assistantSearch.trim()
                    ? "No eligible assistant matches this search."
                    : "No assistant assigned to this task's groups has homework grading permission."}
                </Text>
              </View>
            ) : (
              <ScrollView
                style={styles.assistantList}
                contentContainerStyle={
                  styles.assistantListContent
                }
                nestedScrollEnabled
              >
                {filteredAssistants.map(
                  (assistant) => {
                    const assignedGroupNames =
                      getAssistantGroupNames(
                        assistant.id
                      );

                    return (
                      <View
                        key={assistant.id}
                        style={
                          styles.assistantRow
                        }
                      >
                        <View
                          style={
                            styles.assistantAvatar
                          }
                        >
                          <Text
                            style={
                              styles.assistantAvatarText
                            }
                          >
                            {getInitial(
                              assistant.name
                            )}
                          </Text>
                        </View>

                        <View
                          style={
                            styles.assistantInfo
                          }
                        >
                          <Text
                            numberOfLines={1}
                            style={
                              styles.assistantName
                            }
                          >
                            {assistant.name}
                          </Text>

                          <Text
                            style={
                              styles.assistantRole
                            }
                          >
                            {assistant.isHeadAssistant
                              ? "Head Assistant"
                              : "Assistant"}
                          </Text>

                          <Text
                            numberOfLines={2}
                            style={
                              styles.assistantGroups
                            }
                          >
                            Assigned groups:{" "}
                            {assignedGroupNames.join(
                              ", "
                            ) || "Unavailable"}
                          </Text>
                        </View>

                        <Button
                          title="Delegate"
                          variant="secondary"
                          onPress={() =>
                            delegate(
                              assistant.id
                            )
                          }
                          loading={Boolean(
                            delegatingSubmissionId
                          )}
                          disabled={Boolean(
                            delegatingSubmissionId
                          )}
                        />
                      </View>
                    );
                  }
                )}
              </ScrollView>
            )}

            <View style={styles.modalActions}>
              <Button
                title="Cancel"
                variant="outline"
                onPress={closeDelegateModal}
                disabled={Boolean(
                  delegatingSubmissionId
                )}
              />
            </View>
          </View>
        </View>
      </Modal>
    </Screen>
  );
}